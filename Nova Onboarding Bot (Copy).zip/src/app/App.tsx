import { useState, useEffect, useRef, useCallback } from "react";
import hdfcLogo from "@/imports/hdfc_logo.png";
import {
  Send, LogOut, Sun, Moon, Eye, EyeOff, AlertTriangle,
  CheckCircle, Bot, User as UserIcon, RefreshCw, Clock,
  Menu, X, Plus, Search, FileText, Film,
  Mic, MicOff, Volume2, VolumeX, Download, Folder,
  ChevronLeft, Bookmark, Trash2, Upload, Image,
  ArrowLeft, Home, Users, Settings, Shield, ChevronRight,
  RotateCcw, AlertCircle, FileCheck, Building2, GraduationCap,
  Briefcase, Activity, UserCheck, Check, Filter, MoreVertical,
  Calendar, ChevronDown, UploadCloud, ClipboardList, TrendingUp,
  XCircle, Bell, BarChart2, Pencil,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────
type EmployeeType = "intern" | "permanent" | "contract";
type AppView = "chat" | "documents" | "videos";
type Intent =
  | "team_info" | "office_info" | "access_credentials"
  | "hardware_it" | "hr_policy" | "benefits" | "unknown";
type Phase =
  | "greeting" | "intent" | "retrieval" | "clarification"
  | "escalation" | "post_response" | "end" | "answer";
type UserRole = "intern" | "permanent" | "contract" | "employee" | "hr" | "admin";
type HRView = "dashboard" | "employees" | "reviews" | "knowledge" | "videos" | "required_docs" | "settings";
type DocStatus = "not_uploaded" | "uploaded" | "pending_review" | "approved" | "rejected";

interface Profile {
  id: string;
  full_name: string;
  email: string;
  employee_type: EmployeeType;
  team?: string;
  mentor_name?: string;
  branch?: string;
  role?: UserRole;
  joining_date?: string;
  department?: string;
  manager?: string;
}

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  mandatory: boolean;
  accepted_types: string[];
  max_size_mb: number;
  employee_type: "intern" | "permanent" | "contract" | "both" | "all";
  created_at?: string;
}

interface EmployeeDocument {
  id: string;
  user_id: string;
  required_document_id: string;
  document_type: string;
  storage_path: string;
  status: DocStatus;
  uploaded_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
  remarks?: string;
  file_name?: string;
  file_size?: number;
}

interface EscalationContact { role: string; name: string; email: string; }

interface DocumentMeta {
  id: string;
  title: string;
  description: string;
  file_url: string;
  file_type: string;
  uploaded_by: string;
  uploaded_at: string;
  tags: string[];
  category: string;
  employee_type?: string;
}

interface VideoMeta {
  id: string;
  title: string;
  description: string;
  video_url: string;
  thumbnail?: string;
  mentor: string;
  project: string;
  tags: string[];
  uploaded_at: string;
  duration?: string;
}

interface ConversationSummary {
  session_id: string;
  title: string;
  preview: string;
  date: string;
}

interface ChatMessage {
  id: string;
  speaker: "user" | "nova";
  text: string;
  intent?: Intent;
  phase?: Phase;
  timestamp: Date;
  escalation?: { routed_to: string[] };
  isTyping?: boolean;
  relatedDocs?: DocumentMeta[];
  relatedVideos?: VideoMeta[];
}

// ─── Mock Data ────────────────────────────────────────────────────────────────
const DEMO_PROFILES: Record<string, Profile> = {
  intern: {
    id: "intern-001",
    full_name: "Arjun Mehta",
    email: "arjun.mehta@intern.hdfc.bank.in",
    employee_type: "intern",
    role: "intern",
    team: "Payment Factory",
    mentor_name: "Kunal Jasuja",
    branch: "Bangalore",
    joining_date: "2026-06-15",
    department: "Product & Design",
    manager: "Abhinaya Sharma",
  },
  permanent: {
    id: "perm-001",
    full_name: "Priya Nair",
    email: "priya.nair@hdfcbank.com",
    employee_type: "permanent",
    role: "permanent",
    team: "Technology",
    mentor_name: "Ananya Singh",
    branch: "Mumbai",
    joining_date: "2026-03-01",
    department: "Technology",
    manager: "Rajesh Kumar",
  },
  hr: {
    id: "hr-001",
    full_name: "Kavana Reddy",
    email: "kavana.reddy@hdfcbank.com",
    employee_type: "permanent",
    role: "hr",
    branch: "Bangalore",
    joining_date: "2023-01-10",
    department: "Human Resources",
    manager: "Meera Pillai",
  },
};

const MOCK_REQUIRED_DOCS: RequiredDocument[] = [
  { id: "rd-1", name: "Aadhaar Card", description: "Government-issued Aadhaar card (front & back)", mandatory: true, accepted_types: ["PDF", "JPG", "PNG"], max_size_mb: 5, employee_type: "all", created_at: "2026-01-01" },
  { id: "rd-2", name: "PAN Card", description: "Permanent Account Number card", mandatory: true, accepted_types: ["PDF", "JPG", "PNG"], max_size_mb: 5, employee_type: "all", created_at: "2026-01-01" },
  { id: "rd-3", name: "Bank Account Details", description: "Cancelled cheque or bank passbook first page", mandatory: true, accepted_types: ["PDF", "JPG", "PNG"], max_size_mb: 5, employee_type: "all", created_at: "2026-01-01" },
  { id: "rd-4", name: "10th Marksheet", description: "Secondary school certificate / marksheet", mandatory: true, accepted_types: ["PDF", "JPG"], max_size_mb: 10, employee_type: "all", created_at: "2026-01-01" },
  { id: "rd-5", name: "12th Marksheet", description: "Higher secondary / intermediate marksheet", mandatory: true, accepted_types: ["PDF", "JPG"], max_size_mb: 10, employee_type: "permanent", created_at: "2026-01-01" },
  { id: "rd-6", name: "Signed Offer Letter", description: "Countersigned copy of the offer letter issued by HDFC", mandatory: true, accepted_types: ["PDF"], max_size_mb: 5, employee_type: "all", created_at: "2026-01-01" },
  { id: "rd-7", name: "Passport Photo", description: "Recent passport-size photograph (white background)", mandatory: false, accepted_types: ["JPG", "PNG"], max_size_mb: 2, employee_type: "permanent", created_at: "2026-01-01" },
  { id: "rd-8", name: "Previous Employer Relieving Letter", description: "Relieving or experience letter from last employer", mandatory: false, accepted_types: ["PDF"], max_size_mb: 5, employee_type: "permanent", created_at: "2026-01-01" },
  { id: "rd-9", name: "Internship Offer Letter", description: "Offer letter for internship from HDFC", mandatory: true, accepted_types: ["PDF"], max_size_mb: 5, employee_type: "intern", created_at: "2026-01-01" },
];

const MOCK_EMPLOYEE_DOCUMENTS: EmployeeDocument[] = [
  { id: "ed-1", user_id: "intern-001", required_document_id: "rd-1", document_type: "Aadhaar Card", storage_path: "/mock/aadhaar.pdf", status: "approved", uploaded_at: "2026-06-12T10:30:00Z", reviewed_at: "2026-06-13T14:00:00Z", reviewed_by: "hr-001", file_name: "aadhaar_arjun.pdf", file_size: 820000 },
  { id: "ed-2", user_id: "intern-001", required_document_id: "rd-2", document_type: "PAN Card", storage_path: "/mock/pan.pdf", status: "pending_review", uploaded_at: "2026-06-14T09:15:00Z", file_name: "pan_arjun.pdf", file_size: 610000 },
  { id: "ed-3", user_id: "intern-001", required_document_id: "rd-3", document_type: "Bank Account Details", storage_path: "/mock/bank.pdf", status: "rejected", uploaded_at: "2026-06-11T16:45:00Z", reviewed_at: "2026-06-12T11:00:00Z", reviewed_by: "hr-001", remarks: "Account number is unclear — please re-upload a clearer scan.", file_name: "bank_arjun.pdf", file_size: 340000 },
  { id: "ed-4", user_id: "intern-001", required_document_id: "rd-4", document_type: "10th Marksheet", storage_path: "", status: "not_uploaded", uploaded_at: "", file_name: undefined },
  { id: "ed-5", user_id: "intern-001", required_document_id: "rd-9", document_type: "Internship Offer Letter", storage_path: "/mock/offer.pdf", status: "approved", uploaded_at: "2026-06-10T08:00:00Z", reviewed_at: "2026-06-10T18:00:00Z", reviewed_by: "hr-001", file_name: "offer_letter_arjun.pdf", file_size: 450000 },
  // Permanent employee docs
  { id: "ed-6", user_id: "perm-001", required_document_id: "rd-1", document_type: "Aadhaar Card", storage_path: "/mock/aadhaar_priya.pdf", status: "approved", uploaded_at: "2026-02-25T10:00:00Z", reviewed_at: "2026-02-26T09:00:00Z", reviewed_by: "hr-001", file_name: "aadhaar_priya.pdf", file_size: 720000 },
  { id: "ed-7", user_id: "perm-001", required_document_id: "rd-2", document_type: "PAN Card", storage_path: "/mock/pan_priya.pdf", status: "approved", uploaded_at: "2026-02-25T10:15:00Z", reviewed_at: "2026-02-26T09:05:00Z", reviewed_by: "hr-001", file_name: "pan_priya.pdf", file_size: 530000 },
  { id: "ed-8", user_id: "perm-001", required_document_id: "rd-3", document_type: "Bank Account Details", storage_path: "/mock/bank_priya.pdf", status: "pending_review", uploaded_at: "2026-03-02T11:00:00Z", file_name: "bank_priya.pdf", file_size: 290000 },
  { id: "ed-9", user_id: "perm-001", required_document_id: "rd-5", document_type: "12th Marksheet", storage_path: "", status: "not_uploaded", uploaded_at: "" },
];

type MockEmployee = {
  id: string; full_name: string; email: string; role: UserRole; department: string;
  team: string; joining_date: string; branch: string; manager: string; mentor_name?: string;
  doc_summary: { approved: number; pending: number; rejected: number; total: number };
};

const MOCK_EMPLOYEES: MockEmployee[] = [
  { id: "intern-001", full_name: "Arjun Mehta",    email: "arjun.mehta@intern.hdfc.bank.in", role: "intern",    department: "Product & Design", team: "Payment Factory",   joining_date: "2026-06-15", branch: "Bangalore", manager: "Abhinaya Sharma", mentor_name: "Kunal Jasuja",  doc_summary: { approved: 2, pending: 1, rejected: 1, total: 5 } },
  { id: "perm-001",  full_name: "Priya Nair",       email: "priya.nair@hdfcbank.com",          role: "permanent", department: "Technology",       team: "Core Banking",      joining_date: "2026-03-01", branch: "Mumbai",     manager: "Rajesh Kumar",    doc_summary: { approved: 2, pending: 1, rejected: 0, total: 4 } },
  { id: "emp-003",   full_name: "Rohan Sharma",     email: "rohan.sharma@hdfcbank.com",        role: "permanent", department: "Risk & Compliance",team: "Risk Management",   joining_date: "2026-01-10", branch: "Delhi",      manager: "Sonia Gupta",     doc_summary: { approved: 5, pending: 0, rejected: 0, total: 5 } },
  { id: "emp-004",   full_name: "Sneha Pillai",     email: "sneha.pillai@intern.hdfc.bank.in", role: "intern",    department: "Marketing",       team: "Digital Marketing", joining_date: "2026-06-15", branch: "Bangalore",  manager: "Mithun Das",      mentor_name: "Deepa Rao",    doc_summary: { approved: 1, pending: 2, rejected: 1, total: 4 } },
  { id: "emp-005",   full_name: "Karan Patel",      email: "karan.patel@hdfcbank.com",         role: "contract",  department: "Operations",      team: "Loans Processing",  joining_date: "2026-04-01", branch: "Pune",       manager: "Anjali Mehta",    doc_summary: { approved: 3, pending: 0, rejected: 0, total: 3 } },
  { id: "emp-006",   full_name: "Divya Krishnan",   email: "divya.k@hdfcbank.com",             role: "permanent", department: "Product",         team: "Mobile Banking",    joining_date: "2025-11-15", branch: "Hyderabad",  manager: "Venkat Rao",      doc_summary: { approved: 6, pending: 0, rejected: 0, total: 6 } },
  { id: "emp-007",   full_name: "Aditya Verma",     email: "aditya.verma@intern.hdfc.bank.in", role: "intern",    department: "Technology",      team: "API Platform",      joining_date: "2026-06-15", branch: "Chennai",    manager: "Lakshmi Bai",     mentor_name: "Suresh Kumar",  doc_summary: { approved: 0, pending: 3, rejected: 0, total: 3 } },
  { id: "emp-008",   full_name: "Meera Joshi",      email: "meera.joshi@hdfcbank.com",         role: "permanent", department: "Finance",         team: "Financial Planning", joining_date: "2026-02-01", branch: "Mumbai",     manager: "Ashok Mehta",     doc_summary: { approved: 4, pending: 1, rejected: 1, total: 6 } },
];

const MOCK_HR_DOCS: DocumentMeta[] = [
  { id: "doc-1", title: "HDFC Joining Guidelines 2026", description: "Complete guide for new joiners — what to expect on Day 1, documentation checklist, and office orientation steps.", file_url: "#", file_type: "PDF", uploaded_by: "HR Team", uploaded_at: "2026-05-10T00:00:00Z", tags: ["joining", "onboarding", "day1", "guidelines"], category: "Onboarding", employee_type: "all" },
  { id: "doc-2", title: "Leave Policy 2026 – Permanent Employees", description: "Full leave structure for permanent employees: earned leave, sick leave, maternity, paternity and more.", file_url: "#", file_type: "PDF", uploaded_by: "HR Team", uploaded_at: "2026-01-15T00:00:00Z", tags: ["leave", "policy", "holidays", "permanent"], category: "HR Policy", employee_type: "permanent" },
  { id: "doc-3", title: "Internship Guidelines & Code of Conduct", description: "Expectations, responsibilities and code of conduct for HDFC Bank interns.", file_url: "#", file_type: "PDF", uploaded_by: "HR Team", uploaded_at: "2026-05-20T00:00:00Z", tags: ["intern", "conduct", "policy", "guidelines"], category: "HR Policy", employee_type: "intern" },
  { id: "doc-4", title: "Employee Benefits Handbook", description: "Full overview of benefits available to HDFC Bank employees — insurance, travel reimbursements, payroll access and more.", file_url: "#", file_type: "PDF", uploaded_by: "HR Team", uploaded_at: "2026-02-01T00:00:00Z", tags: ["benefits", "insurance", "payroll", "reimbursement"], category: "Benefits", employee_type: "permanent" },
  { id: "doc-5", title: "IT Security & Acceptable Use Policy", description: "Guidelines for responsible use of HDFC Bank IT systems, data handling, and cybersecurity practices.", file_url: "#", file_type: "PDF", uploaded_by: "IT Team", uploaded_at: "2026-03-05T00:00:00Z", tags: ["IT", "security", "policy", "data"], category: "IT Policy", employee_type: "all" },
  { id: "doc-6", title: "HDFC Brand & Communication Standards", description: "Brand guidelines, communication templates, and email signature standards for all HDFC staff.", file_url: "#", file_type: "PDF", uploaded_by: "Marketing Team", uploaded_at: "2026-04-01T00:00:00Z", tags: ["brand", "communication", "email", "standards"], category: "Brand", employee_type: "all" },
];

const MOCK_HR_VIDEOS: VideoMeta[] = [
  { id: "vid-1", title: "Welcome to HDFC Bank – Your First Week", description: "A warm introduction to HDFC Bank culture, values, and what to expect in your first week as a new joiner.", video_url: "#", mentor: "Meera Pillai", project: "Onboarding Series", tags: ["welcome", "onboarding", "culture", "first week"], uploaded_at: "2026-05-10T00:00:00Z", duration: "12:34" },
  { id: "vid-2", title: "Navigating the HR Portal", description: "Step-by-step walkthrough of the Nova HR portal — uploading documents, checking status, and using the chatbot.", video_url: "#", mentor: "Kavana Reddy", project: "Platform Tutorials", tags: ["nova", "HR portal", "documents", "tutorial"], uploaded_at: "2026-05-15T00:00:00Z", duration: "8:20" },
  { id: "vid-3", title: "Office Tour – Bangalore Design Hub", description: "Virtual tour of the Bangalore design office with key locations, facilities, and how to get around on Day 1.", video_url: "#", mentor: "Kunal Jasuja", project: "Office Orientation", tags: ["office", "bangalore", "tour", "facilities"], uploaded_at: "2026-06-01T00:00:00Z", duration: "6:45" },
  { id: "vid-4", title: "Understanding HDFC Leave Policy", description: "Detailed explainer covering all leave types, how to apply, and the holiday calendar for FY2026.", video_url: "#", mentor: "HR Team", project: "HR Policy Series", tags: ["leave", "policy", "holiday", "HR"], uploaded_at: "2026-04-20T00:00:00Z", duration: "15:10" },
  { id: "vid-5", title: "Cybersecurity Best Practices at HDFC", description: "Essential security practices every HDFC employee needs to follow — passwords, phishing awareness, and data handling.", video_url: "#", mentor: "Darshit Bavisi", project: "IT Training", tags: ["security", "IT", "phishing", "passwords", "data"], uploaded_at: "2026-03-10T00:00:00Z", duration: "18:05" },
];

const MOCK_CONVERSATIONS: ConversationSummary[] = [
  { session_id: "sess-1", title: "Team & Mentor Info", preview: "Who is my mentor? — Your mentor is Kunal Jasuja…", date: new Date(Date.now() - 3 * 86400000).toISOString() },
  { session_id: "sess-2", title: "Office & IT Setup", preview: "Will I get a laptop? — As an intern, you'll work on…", date: new Date(Date.now() - 7 * 86400000).toISOString() },
  { session_id: "sess-3", title: "Leave & Attendance Policy", preview: "What is the leave policy? — The leave structure…", date: new Date(Date.now() - 14 * 86400000).toISOString() },
];

const DASH_ACTIVITY = [
  { day: "Mon", docs: 4, chats: 12 }, { day: "Tue", docs: 7, chats: 18 }, { day: "Wed", docs: 3, chats: 9 },
  { day: "Thu", docs: 8, chats: 22 }, { day: "Fri", docs: 5, chats: 14 }, { day: "Sat", docs: 1, chats: 3 },
];
const ONBOARD_TREND = [
  { month: "Jan", count: 4 }, { month: "Feb", count: 6 }, { month: "Mar", count: 3 },
  { month: "Apr", count: 9 }, { month: "May", count: 7 }, { month: "Jun", count: 12 },
];

// ─── Knowledge Base ───────────────────────────────────────────────────────────
const GREETING_RE = /^(hi|hey|hello|good\s*(morning|afternoon|evening)|howdy|namaste|hola|yo|sup|hiya)[\s!.?]*$/i;
const ELICITATION_PHRASES = [
  "need help", "have questions", "have a question", "onboarding help",
  "can you help", "what can you do", "help me", "just joined",
  "i joined", "new joiner", "new here", "new employee", "new intern",
  "i'm new", "im new", "recently joined", "started today", "first day",
];

const INTENT_PATTERNS: [Intent, string[]][] = [
  ["team_info", ["team","my team","which team","what team","team am i","team will i","team joining","team assigned","abhinaya","mentor","kunal","who is my mentor","who will mentor","who will guide","guide me","mentor assigned","who do i report to for guidance","teammate","team member","colleague","kavana","trisha","suyash","who will i work with","who are my teammates","who all are in my team","who is on my team","immediate team","vertical","payment factory","domain","business area","what does my team do","team focus","which vertical","merchant","project","current project","live project","ongoing project","active project","what is team working on","everyone working on","task","responsibilities","kind of work","what work","what will i do","what kind of task","what kind of work","what should i expect","team size","how many people","headcount","how big is my team","how many members","how many teammates","size of team","number of people","another internship","intern again","reapply","second internship","come back","do internship again","return for internship","eligible for another","can i intern again","future internship"]],
  ["office_info", ["seat","seating","where do i sit","where will i sit","which desk","assigned seat","sitting arrangement","naren","where is my seat","sit in office","where do we sit","location","address","where is the office","office address","maps","where do i go","which office","bangalore office","how to reach","directions","day 1 location","timing","office hour","working hour","what time","office start","when does office","time should i come","standard timing","what are the timings","9:30","6:30","office timings","which day","office day","in office day","come to office","go to office","office schedule","when to come","mandatory day","work from office","wfo","hybrid","wfh","work from home","tuesday","thursday","in-office","in office","saturday","weekend","5 day","five day","work on saturday","dress","attire","dress code","what to wear","formal wear","dress guideline","what should i wear","clothing","semi formal","punch","attendance","mark attendance","clock in","punch in time","attendance time","branch","which branch","bangalore branch","branch assigned","shuttle","transport","cab","bus","office transport","pickup","drop","company shuttle","does hdfc have shuttle","transport system","canteen","cafeteria","food","meal","lunch","tea","coffee","is there canteen","is there food","in-office canteen","place to eat","eat","what for lunch","typically do for lunch","orientation","induction","intern orientation","onboarding session","welcome session","networking","is there orientation","who to ask","who should i ask","who can help","who can i approach","point of contact","first point of contact","whom to contact","who do i go to","approach for questions","confused"]],
  ["access_credentials", ["id card","badge","card","access card","intern id","will i get id card","do interns get id card","issued id","receive id","entry","enter office","how do i enter","authorization","authorisation","need pass","need approval","can i enter","how to enter","sign in","get into the office","get in","email","mail","hdfc email","email id","work email","company email","intern email","figma email","do i get email","will i get email","do interns get email","get an email","official email","account","employee account","login","corporate account","internal account","hdfc account","employee login","do i need account","form","forms","fill form","submit form","which form","what form","application form","internship form","intern form","joining form","onboarding form","project form","training form","project application","internship application","application","submit application","document","documentation","paperwork","what to bring","carry document","offer letter","first day document","day 1 document","do i need to carry","need documentation","joining document","id proof","educational certificate","credential","sso"]],
  ["hardware_it", ["it","laptop","system","computer","device","hardware","desktop","will i get laptop","work laptop","system provided","will i be given a system","do i get a laptop","get a system","provided laptop","own laptop","bring my own laptop","intern laptop","laptop or desktop","desktop or laptop","which system","what device","laptop type","when will i get","when will i get my laptop","when will i get my system","how long","when laptop","when system","receive laptop","how long to get","timeline","how long will it take","it contact","it support","darshit","system not working","laptop issue","who handles it","tech problem","device issue","it person","it team","technical support","who do i approach for it","helpdesk","technical","hardware"]],
  ["hr_policy", ["hr","leave","leaves","paid leave","sick leave","casual leave","earned leave","privilege leave","maternity","paternity","compensatory leave","how many days off","leave structure","leave policy","leave rule","how leaves work","types of leave","what is the leave policy","explain leave","how do leaves work","how many leave","leave count","leave day","intern leave","leave balance","days off","time off","holiday","holiday calendar","public holiday","which holiday","bangalore calendar","which calendar","holiday list","holiday schedule","saturday","weekend","saturday working","is saturday off","saturday a working day","5 day","work on saturday","tuesday thursday","which days office","mandatory day","work from office"]],
  ["benefits", ["benefit","perk","employee benefit","what benefits","what perks","benefits available","benefits do i have","travel","reimburse","reimbursement","commute","travel cost","travel expense","can travel","is travel","travel to office","vvms","travel reimbursement","office travel","claim travel","salary","slip","payslip","pay","salary slip","stipend slip","get salary slip","where is payslip","access payslip","download payslip","salary document","where do i get salary slip","stipend","compensation"]],
];

const INTENT_LABELS: Record<Intent, string> = {
  team_info: "Team Information", office_info: "Office & Facilities",
  access_credentials: "Access & Credentials", hardware_it: "Hardware & IT",
  hr_policy: "HR Policy", benefits: "Benefits & Payroll", unknown: "General Query",
};

const ESCALATION_CONTACTS: EscalationContact[] = [
  { role: "Mentor",  name: "Kunal Jasuja",   email: "kunal.jasuja1@hdfc.bank.in" },
  { role: "IT",      name: "Darshit Bavisi", email: "darshit.bavisi@hdfc.bank.in" },
  { role: "HR",      name: "HR Team",        email: "hr@hdfcbank.com" },
];

const ESCALATION_MAP: Record<Intent, string[]> = {
  team_info: ["Kunal Jasuja","HR Team"], office_info: ["HR Team","Kunal Jasuja"],
  access_credentials: ["HR Team","Kunal Jasuja"], hardware_it: ["Darshit Bavisi","HR Team"],
  hr_policy: ["HR Team","Kunal Jasuja"], benefits: ["HR Team","Kunal Jasuja"], unknown: ["HR Team","Kunal Jasuja"],
};

function kwMatches(text: string, kw: string): boolean {
  if (kw.length >= 4) return text.includes(kw);
  return new RegExp(`(?<![a-z])${kw}(?![a-z])`, "i").test(text);
}

function classifyIntent(text: string): Intent {
  const t = text.toLowerCase();
  const scores: [Intent, number][] = INTENT_PATTERNS.map(([intent, keywords]) => {
    let score = 0;
    for (const kw of keywords) { if (kwMatches(t, kw)) score += kw.split(" ").length; }
    return [intent, score];
  });
  const best = scores.reduce((a, b) => (b[1] > a[1] ? b : a));
  return best[1] > 0 ? best[0] : "unknown";
}

function isGreeting(text: string): boolean { return GREETING_RE.test(text.trim()); }
function isElicitation(text: string): boolean { const t = text.toLowerCase(); return ELICITATION_PHRASES.some(p => t.includes(p)); }
function looksHdfcRelated(text: string): boolean {
  const t = text.toLowerCase();
  for (const [, keywords] of INTENT_PATTERNS) { for (const kw of keywords) { if (kwMatches(t, kw)) return true; } }
  const hdfc = ["hdfc","bank","office","work","team","mentor","salary","leave","laptop","email","intern","employee","onboard","join","policy","id card","badge","it support","credentials","reimburs","holiday","payslip","stipend","form","application","document","training","paperwork"];
  if (hdfc.some(w => t.includes(w))) return true;
  return ["it","hr","id"].some(w => new RegExp(`(?<![a-z])${w}(?![a-z])`, "i").test(t));
}
function isEndSignal(text: string): boolean {
  const t = text.toLowerCase().trim();
  return ["thanks","thank you","that's all","thats all","i'm done","im done","bye","goodbye","ok thanks","okay thanks","got it","all good","nothing else","that will be all","no more questions","done for now","that helps","perfect","great thanks"].some(p => t.includes(p));
}

type KBEntry = { key: string; answer: string; type: "all" | "intern" | "permanent" | "contract"; tags: string[] };

const KNOWLEDGE_BASE: Record<string, KBEntry[]> = {
  team_info: [
    { key: "which_team", type: "all", tags: ["which team am i","what team am i","which team will i","team am i in","team joining","team assigned","abhinaya"], answer: "You're part of your assigned team, based out of your branch office. Your assigned mentor will guide you through your onboarding and day-to-day work." },
    { key: "who_is_mentor", type: "all", tags: ["who is my mentor","who's my mentor","who will mentor me","mentor","kunal","who will guide me","guide me","mentor assigned","my mentor"], answer: "Your mentor will be your primary point of contact for guidance, support, and any questions during your onboarding." },
    { key: "teammates", type: "all", tags: ["who are my team members","who's on my team","who will i be working with","teammates","teammate","colleague","kavana","trisha","suyash","immediate team"], answer: "Your immediate team members are Kavana Reddy, Trisha Khandelwal, and Suyash Tiwari. You'll also have 2 co-interns joining alongside you. The broader team under Abhinaya has 10 members in total." },
    { key: "team_vertical", type: "all", tags: ["what vertical does my team handle","what domain does my team work in","what does my team do","vertical","payment factory","merchant","team focus"], answer: "Your team works under the Payment Factory vertical. Here's what each person is focused on:\n• Kavana Reddy — Payment Gateway\n• Trisha Khandelwal — Merchant Dashboard\n• Suyash Tiwari — Merchant Onboarding\n• Kunal Jasuja — Oversees the entire vertical\n\nYou'll be aligned to a specific workstream once your research phase wraps up." },
    { key: "team_size", type: "all", tags: ["how many members","team size","how many people","headcount","how many teammates","size of team"], answer: "Your immediate team has 3 members — Kavana Reddy, Trisha Khandelwal, and Suyash Tiwari — plus Kunal, your mentor. You'll also have 2 co-interns. The larger team under Abhinaya has 10 members in total." },
    { key: "current_projects", type: "all", tags: ["what projects is my team working on","what is my team currently working on","current project","live project","ongoing project","active project","project","working on"], answer: "The team is currently working on three active projects within the Payment Factory vertical:\n• Payment Gateway — Kavana Reddy\n• Merchant Dashboard — Trisha Khandelwal\n• Merchant Onboarding — Suyash Tiwari\n\nAs a new joiner, you'll likely start with some research before being assigned to a specific workstream." },
    { key: "task_types", type: "all", tags: ["what kind of work will i do","what tasks will i be working on","responsibilities","kind of work","what work","what will i do","type of work"], answer: "You'll start with some research to find a topic for your project. Alongside that, you may be given small design changes or edits on live projects — a great way to get familiar with the team's tools and workflows." },
    { key: "intern_again", type: "intern", tags: ["can i intern at hdfc again","another internship","intern again","reapply","second internship","come back","future internship"], answer: "Absolutely! HDFC would be happy to have you back. When you're ready, just send a fresh application email with your updated portfolio and the team can take it from there." },
  ],
  office_info: [
    { key: "seating", type: "all", tags: ["seat","seating","where do i sit","where will i sit","which desk","assigned seat","naren","where is my seat"], answer: "The design team usually sits towards the left side of the office. Seats aren't strictly assigned — settle in anywhere in that area. Just make sure you don't end up in Naren's usual spot!" },
    { key: "office_location", type: "all", tags: ["location","address","where is the office","office address","maps","where do i go","which office","bangalore office","day 1 location","how to reach","directions"], answer: "The office is in Bangalore. Navigate here: https://maps.app.goo.gl/au7TUupWLcvFEPJC7\n\nHead to the side entrance of the building and go up to the second floor. That's where you'll find the team." },
    { key: "timings", type: "all", tags: ["timing","office hour","working hour","what time","office start","9:30","6:30","office timings"], answer: "The design team works from 9:30 AM to 6:30 PM. Your team typically logs in around 10:00–10:30 AM, so mornings are a bit flexible once you're settled in." },
    { key: "dress_code", type: "all", tags: ["dress","attire","dress code","what to wear","formal wear","dress guideline","what should i wear","clothing","semi formal"], answer: "The dress code is semi-formal. Smart casuals work well — neat trousers, shirts, kurtas, or blouses. Nothing too formal and nothing too casual." },
    { key: "punch_in", type: "all", tags: ["punch","attendance","mark attendance","clock in","punch in time","attendance time"], answer: "You'll need to mark your attendance every day before 9:30 AM." },
    { key: "in_office_days", type: "all", tags: ["which day","office day","in office day","come to office","go to office","when to come","mandatory day","work from office","tuesday","thursday","in-office"], answer: "The design team typically comes in on Tuesdays and Thursdays. Check with your mentor Kunal or your manager about when they'll be in office so you can coordinate." },
    { key: "saturday", type: "all", tags: ["saturday","weekend","saturday working","is saturday off","5 day","five day","work on saturday"], answer: "No, Saturday is not a working day. You'll have a standard 5-day work week, Monday to Friday." },
    { key: "shuttle", type: "all", tags: ["shuttle","transport","cab","bus","office transport","pickup","drop","company shuttle","does hdfc have shuttle","transport system"], answer: "HDFC does not have a shuttle or company transport system. You'll need to arrange your own commute." },
    { key: "canteen", type: "all", tags: ["canteen","cafeteria","food","meal","is there canteen","is there food","in-office canteen","place to eat"], answer: "There's no in-office canteen, but you can get tea or coffee in the office. For lunch, most people bring packed meals, order in, or step out to a nearby restaurant." },
    { key: "lunch", type: "all", tags: ["lunch","lunch arrangement","what do people do for lunch","lunch option","where to eat","what for lunch","typically do for lunch"], answer: "Most people either bring their own lunch, order in, or step out nearby. It's fairly relaxed — do whatever works best for you!" },
    { key: "orientation", type: "intern", tags: ["orientation","intern orientation","induction","onboarding session","welcome session","networking","is there orientation"], answer: "There isn't a formal intern orientation set up. You're welcome to reach out to your mentor Kunal or your team lead to see if any introductory activities are planned for your first week." },
    { key: "who_to_ask", type: "all", tags: ["who to ask","whom to contact","who should i ask","who can help","point of contact","first point of contact","confused","approach for questions","who do i go to"], answer: "Your first point of contact is your mentor, Kunal Jasuja. If he's busy, feel free to reach out to Kavana, Trisha, or Suyash. For HR queries, contact HR directly." },
  ],
  access_credentials: [
    { key: "id_card_intern", type: "intern", tags: ["id card","badge","card","access card","intern id","will i get id card","do interns get id card","issued id"], answer: "As an intern, you will not be issued an ID card." },
    { key: "id_card_permanent", type: "permanent", tags: ["id card","badge","card","access card","will i get id card","employee badge","when will i get id card"], answer: "Yes, as a permanent employee you will receive an official HDFC ID card. It typically takes around a month or a little more to get issued." },
    { key: "office_entry", type: "all", tags: ["entry","enter office","how do i enter","authorization","need pass","can i enter","how to enter"], answer: "You don't need any special authorization to enter the office. Simply sign in at the front desk and you're good to go." },
    { key: "hdfc_email_intern", type: "intern", tags: ["email","mail","hdfc email","email id","work email","company email","intern email","figma email","do i get email","will i get email","do interns get email"], answer: "As an intern, you won't be assigned a personal HDFC work email. You may get access to a shared email ID specifically for Figma access, if needed." },
    { key: "hdfc_email_permanent", type: "permanent", tags: ["email","mail","hdfc email","email id","work email","company email","when will my email","get an email","official email"], answer: "Yes, as a permanent employee you'll receive an official HDFC email ID within 2–3 working days of joining. If delayed, reach out to HR or Darshit for assistance." },
    { key: "employee_account", type: "all", tags: ["account","employee account","login","corporate account","internal account","hdfc account","employee login"], answer: "Yes, you'll be asked to create a corporate account with HDFC Bank as part of your onboarding. HR will guide you through the steps." },
    { key: "first_day_docs_intern", type: "intern", tags: ["document","documentation","paperwork","what to bring","carry document","offer letter","first day document","day 1 document","joining document"], answer: "As an intern, you won't be asked to bring any formal documentation on your first day. Keep your offer letter handy just in case." },
    { key: "first_day_docs_permanent", type: "permanent", tags: ["document","documentation","paperwork","what to bring","carry document","offer letter","first day document","day 1 document","joining document","id proof","educational certificate"], answer: "As a permanent employee, bring your joining documents — offer letter, government-issued ID, educational certificates, and previous employer documents if applicable. HR will share a full checklist." },
  ],
  hardware_it: [
    { key: "system_allocation_intern", type: "intern", tags: ["laptop","system","computer","device","hardware","will i get laptop","intern laptop","own system","bring my own laptop","do i get a laptop"], answer: "As an intern, HDFC will not provide you with a work system. You'll work on your own laptop throughout your internship." },
    { key: "system_allocation_permanent", type: "permanent", tags: ["laptop","system","computer","device","hardware","will i get laptop","work laptop","system provided","do i get a laptop"], answer: "Yes, as a permanent employee you'll receive a work laptop within a week of joining, or sooner. If delayed, reach out to Darshit Bavisi from IT." },
    { key: "it_contact", type: "all", tags: ["it contact","it support","darshit","system not working","laptop issue","who handles it","tech problem","device issue","it person","it team","technical support","helpdesk"], answer: "For any IT-related issues — system setup, software access, network, or devices — reach out to Darshit Bavisi from the IT team at darshit.bavisi@hdfc.bank.in." },
  ],
  hr_policy: [
    { key: "leave_intern", type: "intern", tags: ["leave","leaves","how many leaves","intern leave","leave structure","days off","leave policy"], answer: "As an intern at HDFC Bank, you're entitled to a limited number of casual leaves. The exact count depends on your internship duration — check with your mentor Kunal or HR for the specific count applicable to you." },
    { key: "leave_permanent", type: "permanent", tags: ["leave","leaves","paid leave","sick leave","casual leave","earned leave","privilege leave","leave structure","leave policy","types of leave"], answer: "As a permanent employee, you'll have access to:\n• Casual Leave (CL)\n• Sick Leave (SL)\n• Earned / Privilege Leave (EL/PL)\n• Maternity / Paternity Leave\n• Compensatory Off (if applicable)\n\nFor the exact count and rules, refer to the Leave Policy document in the Resources section or contact HR." },
    { key: "holiday_calendar", type: "all", tags: ["holiday","holiday calendar","public holiday","which holiday","bangalore calendar","holiday list","holiday schedule"], answer: "HDFC follows a regional holiday calendar. For the full list of public holidays in your location, refer to the Holiday Calendar document shared by HR or check with your branch HR." },
    { key: "wfo_schedule", type: "all", tags: ["which days office","mandatory day","work from office","tuesday","thursday","in-office","wfo","hybrid"], answer: "The design team's in-office days are typically Tuesday and Thursday. Check with your mentor or manager for your team-specific schedule." },
  ],
  benefits: [
    { key: "travel_reimbursement", type: "permanent", tags: ["travel","reimburse","reimbursement","commute","travel cost","travel expense","travel to office","vvms","travel reimbursement","claim travel"], answer: "Permanent employees are eligible for travel reimbursement through the VVMS portal. Raise a claim after your travel with supporting receipts. Check with HR for the applicable limits and process." },
    { key: "payslip", type: "permanent", tags: ["salary","slip","payslip","pay","salary slip","get salary slip","where is payslip","access payslip","download payslip"], answer: "Your payslip is available through the HDFC employee self-service portal. You'll receive login credentials within your first month. If you face delays, contact HR." },
    { key: "stipend", type: "intern", tags: ["salary","stipend","compensation","stipend slip","pay"], answer: "Your internship stipend will be processed monthly. You'll receive a payment summary at the end of each month. For queries about the amount or timeline, contact HR." },
  ],
};

function scoreEntries(entries: KBEntry[], query: string, employeeType: EmployeeType): { entry: KBEntry; score: number } | null {
  const ql = query.toLowerCase();
  let best: { entry: KBEntry; score: number } | null = null;
  for (const entry of entries) {
    if (entry.type !== "all" && entry.type !== employeeType) continue;
    let score = 0;
    const keyText = entry.key.replace(/_/g, " ");
    if (ql.includes(keyText)) score += keyText.split(" ").length * 2;
    for (const tag of entry.tags) { if (ql.includes(tag.toLowerCase())) score += tag.split(" ").length; }
    if (score > (best?.score ?? 0)) best = { entry, score };
  }
  return best;
}

function profileOverride(intent: Intent, query: string, profile: Profile): string | null {
  const q = query.toLowerCase();
  if (intent === "team_info") {
    const mentorSignals = ["mentor","who will guide","who do i report","who is assigned as my mentor","guide me","my mentor","kunal"];
    const teamSignals = ["which team am i","what team am i","which team will i","team am i in","team will i be in","team joining","team assigned","abhinaya"];
    if (mentorSignals.some(s => q.includes(s))) {
      const name = profile.mentor_name;
      return name ? `Your mentor is ${name}. They will be your primary point of contact for guidance and support during your onboarding.` : "Your mentor hasn't been assigned yet. Check with HR or your reporting manager for details.";
    }
    if (teamSignals.some(s => q.includes(s))) {
      const parts: string[] = [];
      if (profile.team) parts.push(`You're part of the ${profile.team} team`);
      if (profile.branch) parts.push(`based out of the ${profile.branch} office`);
      const base = parts.length ? parts.join(", ") + "." : "Your team details haven't been set yet.";
      return profile.mentor_name ? `${base} Your assigned mentor is ${profile.mentor_name}.` : base;
    }
  }
  if (intent === "office_info") {
    const branchSignals = ["which branch","my branch","branch assigned","which office branch","which location","what branch","branch am i"];
    if (branchSignals.some(s => q.includes(s))) {
      return profile.branch ? `You'll be working out of the ${profile.branch} branch.` : "Your branch hasn't been assigned yet. Check with HR for details.";
    }
  }
  return null;
}

function retrieveAnswer(intent: Intent, userMessage: string, employeeType: EmployeeType, profile: Profile): string | null {
  const override = profileOverride(intent, userMessage, profile);
  if (override) return override;
  const kbResult = scoreEntries(KNOWLEDGE_BASE[intent] ?? [], userMessage, employeeType);
  return kbResult?.entry.answer ?? null;
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function uid() { return Math.random().toString(36).slice(2, 10); }
function novaMsg(text: string, phase: Phase, intent?: Intent, escalation?: { routed_to: string[] }): ChatMessage {
  return { id: uid(), speaker: "nova", text, phase, intent, timestamp: new Date(), escalation };
}
function relativeDate(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso); const now = new Date(); const diff = now.getTime() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Today"; if (days === 1) return "Yesterday";
  if (days < 7) return `${days} days ago`;
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

// ─── Hooks ────────────────────────────────────────────────────────────────────
function useDarkMode() {
  const [dark, setDark] = useState(() => {
    try { const s = localStorage.getItem("nova-dark"); return s !== null ? s === "true" : false; } catch { return false; }
  });
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try { localStorage.setItem("nova-dark", String(dark)); } catch { /* ignore */ }
  }, [dark]);
  return [dark, setDark] as const;
}

declare global { interface Window { SpeechRecognition: typeof SpeechRecognition; webkitSpeechRecognition: typeof SpeechRecognition; } }

function useVoiceInput(onResult: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const recRef = useRef<SpeechRecognition | null>(null);
  const supported = typeof window !== "undefined" && !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  const toggle = useCallback(() => {
    if (!supported) return;
    if (listening) { recRef.current?.stop(); setListening(false); return; }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR(); rec.continuous = false; rec.interimResults = false; rec.lang = "en-IN";
    rec.onresult = (e: SpeechRecognitionEvent) => { onResult(e.results[0][0].transcript); };
    rec.onend = () => setListening(false); rec.onerror = () => setListening(false);
    rec.start(); recRef.current = rec; setListening(true);
  }, [listening, onResult, supported]);
  return { listening, toggle, supported };
}

function useVoiceOutput() {
  const [enabled, setEnabled] = useState(false);
  const speak = useCallback((text: string) => {
    if (!enabled || typeof window === "undefined") return;
    window.speechSynthesis.cancel();
    const clean = text.replace(/<[^>]+>/g, "").replace(/\n/g, " ").slice(0, 500);
    const utt = new SpeechSynthesisUtterance(clean); utt.lang = "en-IN"; utt.rate = 0.95; utt.pitch = 1;
    const voices = window.speechSynthesis.getVoices(); const pref = voices.find(v => v.lang === "en-IN") || voices.find(v => v.lang.startsWith("en"));
    if (pref) utt.voice = pref; window.speechSynthesis.speak(utt);
  }, [enabled]);
  const stop = useCallback(() => { window.speechSynthesis.cancel(); }, []);
  return { enabled, setEnabled, speak, stop };
}

// ─── renderAnswer ─────────────────────────────────────────────────────────────
const LINK_CLS = "text-[#1C3FCA] dark:text-[#4F6EE0] underline underline-offset-2 hover:opacity-75 transition";

function renderAnswer(text: string) {
  const ANCHOR_RE = /<a\s+href="(mailto:[^"]+|https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  const PLAIN_EMAIL_RE = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  const PLAIN_URL_RE = /https?:\/\/[^\s<>"]+/g;
  type Token = { type: "text"; value: string } | { type: "link"; href: string; label: string };
  const tokens: Token[] = [];
  let cursor = 0; let match: RegExpExecArray | null;
  ANCHOR_RE.lastIndex = 0;
  while ((match = ANCHOR_RE.exec(text)) !== null) {
    if (match.index > cursor) tokens.push({ type: "text", value: text.slice(cursor, match.index) });
    tokens.push({ type: "link", href: match[1], label: match[2] });
    cursor = match.index + match[0].length;
  }
  if (cursor < text.length) tokens.push({ type: "text", value: text.slice(cursor) });
  const result: React.ReactNode[] = [];
  tokens.forEach((tok, ti) => {
    if (tok.type === "link") {
      result.push(<a key={ti} href={tok.href} target={tok.href.startsWith("mailto") ? undefined : "_blank"} rel="noopener noreferrer" className={LINK_CLS}>{tok.label}</a>);
    } else {
      const parts = tok.value.split(PLAIN_URL_RE);
      const urls = tok.value.match(PLAIN_URL_RE) ?? [];
      const emailParts = tok.value.split(PLAIN_EMAIL_RE);
      const emails = tok.value.match(PLAIN_EMAIL_RE) ?? [];
      if (urls.length === 0 && emails.length === 0) {
        tok.value.split("\n").forEach((line, li, arr) => {
          result.push(<span key={`${ti}-${li}`}>{line}</span>);
          if (li < arr.length - 1) result.push(<br key={`br-${ti}-${li}`} />);
        });
      } else if (urls.length > 0) {
        parts.forEach((p, pi) => {
          p.split("\n").forEach((line, li, arr) => {
            result.push(<span key={`${ti}-p${pi}-l${li}`}>{line}</span>);
            if (li < arr.length - 1) result.push(<br key={`br-${ti}-p${pi}-l${li}`} />);
          });
          if (pi < urls.length) result.push(<a key={`url-${ti}-${pi}`} href={urls[pi]} target="_blank" rel="noopener noreferrer" className={LINK_CLS}>{urls[pi]}</a>);
        });
      } else {
        emailParts.forEach((p, pi) => {
          result.push(<span key={`${ti}-ep${pi}`}>{p}</span>);
          if (pi < emails.length) result.push(<a key={`email-${ti}-${pi}`} href={`mailto:${emails[pi]}`} className={LINK_CLS}>{emails[pi]}</a>);
        });
      }
    }
  });
  return <>{result}</>;
}

// ─── Auth Gate ────────────────────────────────────────────────────────────────
function AuthGate({ onAuth }: { onAuth: (p: Profile) => void }) {
  const [dark, setDark] = useDarkMode();
  const inp = "w-full px-4 py-3 rounded-xl border border-[#D2D5DB] dark:border-[#1F2D4A] bg-[#F5F6FB] dark:bg-[#1A2340] text-[#111827] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1C3FCA] focus:border-transparent transition text-sm";
  const lbl = "block text-[11px] font-semibold text-[#374151] dark:text-[#9CA3AF] mb-1.5 uppercase tracking-wide";

  const demos: { key: string; label: string; subtitle: string; icon: React.ReactNode; color: string }[] = [
    { key: "intern",    label: "Intern",             subtitle: "Arjun Mehta · Payment Factory · Bangalore", icon: <GraduationCap size={16} />, color: "#F99F35" },
    { key: "permanent", label: "Permanent Employee",  subtitle: "Priya Nair · Technology · Mumbai",          icon: <Briefcase size={16} />,     color: "#00875F" },
    { key: "hr",        label: "HR / Admin",          subtitle: "Kavana Reddy · HR Department",              icon: <Shield size={16} />,        color: "#1C3FCA" },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-10 bg-gradient-to-br from-[#F9FAFF] via-[#D0DDFC] to-[#a8baf7] dark:from-[#0A0F1E] dark:via-[#0f1e45] dark:to-[#1C3FCA]">
      <button onClick={() => setDark(d => !d)} className="fixed top-5 right-5 p-2 rounded-full bg-white dark:bg-[#111827] border border-[#D2D5DB] dark:border-[#1F2D4A] text-[#374151] dark:text-[#9CA3AF] hover:bg-[#F3F6FD] dark:hover:bg-[#1A2340] transition" aria-label="Toggle dark mode">
        {dark ? <Sun size={15} /> : <Moon size={15} />}
      </button>

      <div className="mb-8 text-center">
        <div className="flex items-center justify-center gap-2.5 mb-3">
          <div className="w-11 h-11 overflow-hidden shadow-lg shadow-[#1C3FCA]/30 shrink-0">
            <img src={hdfcLogo} alt="HDFC Bank" className="w-full h-full object-contain rounded-[4px]" />
          </div>
          <span className="text-3xl font-bold text-[#111827] dark:text-[#F5F6FB] tracking-tight">Nova</span>
        </div>
        <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">HDFC Bank · New Joiner Onboarding Assistant</p>
        <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E30613]/10 text-[#E30613] text-xs font-semibold">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E30613] animate-pulse" />Portfolio Demo
        </div>
      </div>

      <div className="w-full max-w-[440px] bg-white dark:bg-[#111827] rounded-2xl shadow-xl shadow-black/6 dark:shadow-black/40 border border-[#D2D5DB] dark:border-[#1F2D4A] overflow-hidden">
        <div className="px-8 pt-7 pb-3">
          <h2 className="text-lg font-bold text-[#111827] dark:text-[#F5F6FB]">Try a demo</h2>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">Select a role to explore the full onboarding experience</p>
        </div>

        <div className="px-8 pb-8 space-y-3">
          {demos.map(({ key, label, subtitle, icon, color }) => (
            <button key={key} onClick={() => onAuth(DEMO_PROFILES[key])}
              className="w-full flex items-center gap-4 px-4 py-4 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] bg-[#F9FAFF] dark:bg-[#1A2340] hover:border-[#1C3FCA]/50 hover:shadow-md transition text-left group">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105" style={{ background: `${color}18`, color }}>
                {icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">{label}</p>
                <p className="text-xs text-[#9CA3AF] mt-0.5 truncate">{subtitle}</p>
              </div>
              <ChevronRight size={16} className="text-[#D1D5DB] group-hover:text-[#1C3FCA] transition shrink-0" />
            </button>
          ))}
        </div>

        <div className="px-8 pb-6 border-t border-[#F3F4F6] dark:border-[#1F2D4A] pt-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="flex-1 h-px bg-[#E5E7EB] dark:bg-[#1F2D4A]" />
            <span className="text-xs text-[#9CA3AF]">or sign in</span>
            <div className="flex-1 h-px bg-[#E5E7EB] dark:bg-[#1F2D4A]" />
          </div>
          <div className="space-y-3 opacity-50 pointer-events-none select-none">
            <div><label className={lbl}>Email</label><input type="email" placeholder="Enter your work email" className={inp} readOnly /></div>
            <div><label className={lbl}>Password</label><input type="password" placeholder="Password disabled in demo" className={inp} readOnly /></div>
            <button className="w-full py-3.5 mt-1 rounded-xl bg-[#1C3FCA] text-white font-semibold text-sm shadow-md shadow-[#1C3FCA]/25 cursor-not-allowed">Sign In to Nova</button>
          </div>
        </div>
      </div>
      <div className="text-xs text-[#838FA0] dark:text-[#4B5563] text-center max-w-xs mx-auto mt-4 font-medium">Portfolio prototype — all data is mock. No real credentials are stored or transmitted.</div>
    </div>
  );
}

// ─── DocStatusBadge ───────────────────────────────────────────────────────────
function DocStatusBadge({ status }: { status: DocStatus }) {
  const cfg: Record<DocStatus, { label: string; cls: string }> = {
    approved:       { label: "Approved",       cls: "bg-[#00875F]/10 text-[#00875F] border-[#00875F]/20" },
    pending_review: { label: "Under Review",   cls: "bg-[#F99F35]/10 text-[#F99F35] border-[#F99F35]/20" },
    uploaded:       { label: "Uploaded",       cls: "bg-[#1C3FCA]/10 text-[#1C3FCA] border-[#1C3FCA]/20" },
    rejected:       { label: "Rejected",       cls: "bg-[#E22853]/10 text-[#E22853] border-[#E22853]/20" },
    not_uploaded:   { label: "Not Uploaded",   cls: "bg-[#9CA3AF]/10 text-[#9CA3AF] border-[#9CA3AF]/20" },
  };
  const { label, cls } = cfg[status] ?? { label: status, cls: "bg-[#9CA3AF]/10 text-[#9CA3AF]" };
  return <span className={`inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full border ${cls}`}>{label}</span>;
}

// ─── DocCard / VidCard ────────────────────────────────────────────────────────
function DocCard({ doc, onOpen, isSaved, onSave }: { doc: DocumentMeta; onOpen: (d: DocumentMeta) => void; isSaved: boolean; onSave: (id: string) => void }) {
  return (
    <div className="flex items-center gap-3 p-3 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-xl hover:border-[#1C3FCA]/30 transition group">
      <div className="w-8 h-8 rounded-lg bg-[#1C3FCA]/10 flex items-center justify-center shrink-0">
        <FileText size={14} className="text-[#1C3FCA]" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-[#111827] dark:text-[#F5F6FB] truncate">{doc.title}</p>
        <p className="text-[10px] text-[#9CA3AF]">{doc.file_type} · {relativeDate(doc.uploaded_at)}</p>
      </div>
      <div className="flex gap-1 shrink-0">
        <button onClick={() => onSave(doc.id)} title={isSaved ? "Unsave" : "Save"} className={`p-1.5 rounded-lg transition ${isSaved ? "text-[#1C3FCA]" : "text-[#9CA3AF] hover:text-[#1C3FCA]"} hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340]`}>
          <Bookmark size={12} fill={isSaved ? "currentColor" : "none"} />
        </button>
        <button onClick={() => onOpen(doc)} className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340] transition">
          <Eye size={12} />
        </button>
      </div>
    </div>
  );
}

function VidCard({ vid, onOpen, isSaved, onSave }: { vid: VideoMeta; onOpen: (v: VideoMeta) => void; isSaved: boolean; onSave: (id: string) => void }) {
  return (
    <div className="flex items-center gap-3 p-3 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-xl hover:border-[#1C3FCA]/30 transition group">
      <div className="w-8 h-8 rounded-lg bg-[#E22853]/10 flex items-center justify-center shrink-0">
        <Film size={14} className="text-[#E22853]" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-[#111827] dark:text-[#F5F6FB] truncate">{vid.title}</p>
        <p className="text-[10px] text-[#9CA3AF]">{vid.mentor} · {vid.duration}</p>
      </div>
      <div className="flex gap-1 shrink-0">
        <button onClick={() => onSave(vid.id)} title={isSaved ? "Unsave" : "Save"} className={`p-1.5 rounded-lg transition ${isSaved ? "text-[#1C3FCA]" : "text-[#9CA3AF] hover:text-[#1C3FCA]"} hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340]`}>
          <Bookmark size={12} fill={isSaved ? "currentColor" : "none"} />
        </button>
        <button onClick={() => onOpen(vid)} className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340] transition">
          <Eye size={12} />
        </button>
      </div>
    </div>
  );
}

// ─── Doc/Video Viewer Modals ──────────────────────────────────────────────────
// ─── Mock Document Renderers ──────────────────────────────────────────────────
function DocPreviewPlaceholder() {
  return (
    <div className="w-full flex flex-col items-center justify-center py-16 px-8 bg-[#F3F4F6] dark:bg-[#1A2340] rounded-2xl border border-[#E5E7EB] dark:border-[#1F2D4A]">
      <div className="w-16 h-16 rounded-2xl bg-[#E5E7EB] dark:bg-[#263052] flex items-center justify-center mb-4">
        <FileText size={28} className="text-[#9CA3AF]" />
      </div>
      <p className="text-sm font-medium text-[#6B7280] dark:text-[#9CA3AF] text-center">Uploaded documents will have a preview here</p>
    </div>
  );
}

function MockEmployeeDocContent(_props: { docType: string; employeeName: string }) {
  return <DocPreviewPlaceholder />;
}

// ─── Employee Document Preview Modal (HR) ─────────────────────────────────────
function EmployeeDocPreviewModal({ doc, employeeName, onClose }: { doc: EmployeeDocument; employeeName: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-[#F9FAFF] dark:bg-[#0A0F1E] rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-[#E5E7EB] dark:border-[#1F2D4A] overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-white dark:bg-[#0D1428] border-b border-[#E5E7EB] dark:border-[#1F2D4A] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#1C3FCA]/10 flex items-center justify-center shrink-0"><FileText size={16} className="text-[#1C3FCA]" /></div>
            <div>
              <p className="text-sm font-bold text-[#111827] dark:text-[#F5F6FB]">{doc.document_type}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <p className="text-xs text-[#9CA3AF]">Submitted by {employeeName}</p>
                <DocStatusBadge status={doc.status} />
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6" style={{ scrollbarWidth: "thin" }}>
          <MockEmployeeDocContent docType={doc.document_type} employeeName={employeeName} />
        </div>
        {/* Footer meta */}
        {doc.file_name && (
          <div className="px-6 py-3 bg-white dark:bg-[#0D1428] border-t border-[#E5E7EB] dark:border-[#1F2D4A] flex items-center justify-between text-xs text-[#9CA3AF] shrink-0">
            <span>{doc.file_name}{doc.file_size ? ` · ${(doc.file_size / 1024 / 1024).toFixed(1)}MB` : ""}</span>
            <span>Uploaded {relativeDate(doc.uploaded_at)}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function DocViewerModal({ doc, onClose }: { doc: DocumentMeta; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-[#F9FAFF] rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-[#E5E7EB] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-[#E5E7EB] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#1C3FCA]/10 flex items-center justify-center shrink-0"><FileText size={16} className="text-[#1C3FCA]" /></div>
            <div><p className="text-sm font-bold text-[#111827]">{doc.title}</p><p className="text-xs text-[#9CA3AF]">{doc.category} · {doc.file_type}</p></div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] hover:bg-[#F5F6FB] transition"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6" style={{ scrollbarWidth: "thin" }}>
          <DocPreviewPlaceholder />
        </div>
        <div className="px-6 py-3 bg-white border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#9CA3AF] shrink-0">
          <span>Uploaded by {doc.uploaded_by}</span>
          <span>{relativeDate(doc.uploaded_at)}</span>
        </div>
      </div>
    </div>
  );
}

function VideoViewerModal({ vid, onClose }: { vid: VideoMeta; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-[#0D1428] rounded-2xl shadow-2xl w-full max-w-lg border border-[#E5E7EB] dark:border-[#1F2D4A] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E7EB] dark:border-[#1F2D4A]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#E22853]/10 flex items-center justify-center shrink-0"><Film size={16} className="text-[#E22853]" /></div>
            <div><p className="text-sm font-bold text-[#111827] dark:text-[#F5F6FB]">{vid.title}</p><p className="text-xs text-[#9CA3AF]">{vid.mentor} · {vid.duration}</p></div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><X size={16} /></button>
        </div>
        <div className="px-6 py-6">
          <p className="text-sm text-[#374151] dark:text-[#9CA3AF] leading-relaxed mb-4">{vid.description}</p>
          <div className="flex flex-wrap gap-2 mb-5">
            {vid.tags.map(t => <span key={t} className="px-2.5 py-1 rounded-full bg-[#FFF0F3] dark:bg-[#2A0A10] text-[#E22853] dark:text-[#F87096] text-xs font-medium">#{t}</span>)}
          </div>
          <div className="aspect-video bg-[#111827] rounded-xl flex flex-col items-center justify-center gap-2">
            <Film size={36} className="text-[#374151]" />
            <p className="text-sm text-[#6B7280]">Video preview not available in demo mode.</p>
          </div>
          <div className="mt-4 flex justify-between items-center text-xs text-[#9CA3AF]">
            <span>Project: {vid.project}</span>
            <span>{relativeDate(vid.uploaded_at)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Chat Bubble Components ───────────────────────────────────────────────────
function NovaBubble({ msg, onViewDoc, onViewVideo, savedDocIds, savedVideoIds, onSaveDoc, onSaveVideo, contacts }: {
  msg: ChatMessage; onViewDoc: (d: DocumentMeta) => void; onViewVideo: (v: VideoMeta) => void;
  savedDocIds: Set<string>; savedVideoIds: Set<string>; onSaveDoc: (id: string) => void; onSaveVideo: (id: string) => void;
  contacts: EscalationContact[];
}) {
  const time = msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return (
    <div className="flex gap-3 items-start">
      <div className="w-8 h-8 rounded-full bg-[#1C3FCA]/10 border border-[#1C3FCA]/20 flex items-center justify-center shrink-0 mt-0.5 overflow-hidden">
        <img src={hdfcLogo} alt="Nova" className="w-5 h-5 object-contain" />
      </div>
      <div className="max-w-[85%] flex flex-col gap-1.5">
        {msg.isTyping ? (
          <div className="bg-[#F5F6FB] dark:bg-[#111827] border border-[#D2D5DB] dark:border-[#1F2D4A] rounded-2xl rounded-tl-sm px-4 py-3 flex gap-1.5 items-center">
            {[0, 1, 2].map(i => <span key={i} className="w-2 h-2 rounded-full bg-[#9CA3AF] animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />)}
          </div>
        ) : msg.escalation ? (
          <div className="flex flex-col gap-2">
            <div className="bg-[#F5F6FB] dark:bg-[#111827] border border-[#D2D5DB] dark:border-[#1F2D4A] rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-[#111827] dark:text-[#F5F6FB] leading-relaxed">{renderAnswer(msg.text)}</div>
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-[#F99F35]/10 border border-[#F99F35]/25">
              <AlertTriangle size={15} className="text-[#F99F35] mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-bold text-[#F99F35] uppercase tracking-wide mb-1.5">Escalation Required</p>
                <p className="text-xs text-[#374151] dark:text-[#9CA3AF] mb-2">Please contact the relevant team for assistance:</p>
                <div className="flex flex-col gap-2">
                  {msg.escalation.routed_to.map((name) => {
                    const merged = [...ESCALATION_CONTACTS, ...contacts];
                    const contact = merged.find(c => c.name.toLowerCase() === name.toLowerCase() || c.role.toLowerCase() === name.toLowerCase());
                    return (
                      <div key={name} className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-full bg-[#F99F35]/20 text-[#F99F35] text-xs font-semibold shrink-0">{name}</span>
                        {contact?.email && <a href={`mailto:${contact.email}`} className="text-xs text-[#1C3FCA] dark:text-[#4F6EE0] underline underline-offset-2 hover:opacity-75 transition">{contact.email}</a>}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-[#F5F6FB] dark:bg-[#111827] border border-[#D2D5DB] dark:border-[#1F2D4A] rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-[#111827] dark:text-[#F5F6FB] leading-relaxed whitespace-pre-wrap">
            {renderAnswer(msg.text)}
          </div>
        )}
        {msg.relatedDocs && msg.relatedDocs.length > 0 && (
          <div className="mt-1 space-y-1.5">
            <p className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider pl-1">Related Documents</p>
            {msg.relatedDocs.map(doc => <DocCard key={doc.id} doc={doc} onOpen={onViewDoc} isSaved={savedDocIds.has(doc.id)} onSave={onSaveDoc} />)}
          </div>
        )}
        {msg.relatedVideos && msg.relatedVideos.length > 0 && (
          <div className="mt-1 space-y-1.5">
            <p className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider pl-1">Related Videos</p>
            {msg.relatedVideos.map(vid => <VidCard key={vid.id} vid={vid} onOpen={onViewVideo} isSaved={savedVideoIds.has(vid.id)} onSave={onSaveVideo} />)}
          </div>
        )}
        <div className="flex items-center gap-1.5 pl-1">
          {msg.intent && msg.intent !== "unknown" && !msg.escalation && (
            <><CheckCircle size={11} className="text-[#00875F]" /><span className="text-[11px] text-[#00875F] font-medium">{INTENT_LABELS[msg.intent]}</span><span className="text-[11px] text-[#D2D5DB] dark:text-[#374151]">·</span></>
          )}
          <span className="text-[11px] text-[#9CA3AF]">{time}</span>
        </div>
      </div>
    </div>
  );
}

function UserBubble({ msg }: { msg: ChatMessage }) {
  return (
    <div className="flex gap-3 items-start justify-end">
      <div className="max-w-[82%]">
        <div className="bg-[#EEF2FF] dark:bg-[#1A2340] border border-[#C7D2F6] dark:border-[#2A3A5C] rounded-2xl rounded-tr-sm px-4 py-3 text-sm text-[#1C3FCA] dark:text-[#A5B8F5] leading-relaxed">{msg.text}</div>
        <p className="text-[11px] text-[#9CA3AF] text-right pr-1 mt-1">{msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
      </div>
      <div className="w-8 h-8 rounded-full bg-[#D0DDFC] dark:bg-[#1A2340] border border-[#1C3FCA]/20 flex items-center justify-center shrink-0 mt-0.5">
        <UserIcon size={13} className="text-[#1C3FCA] dark:text-[#4F6EE0]" />
      </div>
    </div>
  );
}

// ─── Welcome Screen ───────────────────────────────────────────────────────────
function WelcomeScreen({ profile, onSend }: { profile: Profile; onSend: (text: string) => void }) {
  const firstName = (profile.full_name ?? "there").split(" ")[0];
  const suggestions = profile.employee_type === "intern"
    ? ["Who is my mentor?", "Where do I sit?", "Will I get a laptop?", "How many leaves do I get?", "Do I get an HDFC email?"]
    : ["Who is my mentor?", "Where do I sit?", "When will I get my laptop?", "Can my travel be reimbursed?", "What is the leave policy?"];
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 text-center">
      <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-xl shadow-[#1C3FCA]/20 mb-6 shrink-0">
        <img src={hdfcLogo} alt="HDFC Bank" className="w-full h-full object-contain" />
      </div>
      <h1 className="text-2xl font-bold text-[#111827] dark:text-[#F5F6FB] mb-2">Hi {firstName}, I'm Nova 👋</h1>
      <p className="text-[#6B7280] dark:text-[#9CA3AF] text-sm max-w-md mb-10">Your AI onboarding assistant for HDFC Bank. Ask me anything about your team, office, policies, or tools.</p>
      <div className="flex flex-wrap justify-center gap-2 max-w-xl">
        {suggestions.map(s => (
          <button key={s} onClick={() => onSend(s)} className="px-4 py-2 rounded-full text-sm border border-[#D2D5DB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428] text-[#374151] dark:text-[#9CA3AF] hover:border-[#1C3FCA] hover:text-[#1C3FCA] hover:bg-[#F3F6FD] dark:hover:bg-[#1A2340] dark:hover:text-[#4F6EE0] transition">{s}</button>
        ))}
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
function Sidebar({
  collapsed, onToggle, view, onViewChange, conversations, searchQuery, onSearch,
  onNewChat, onSelectConversation, onDeleteConversation, currentSessionId,
  profile, onSignOut, dark, onToggleDark,
}: {
  collapsed: boolean; onToggle: () => void; view: AppView; onViewChange: (v: AppView) => void;
  conversations: ConversationSummary[]; searchQuery: string; onSearch: (q: string) => void;
  onNewChat: () => void; onSelectConversation: (id: string) => void; onDeleteConversation: (id: string) => void;
  currentSessionId: string | null; profile: Profile; onSignOut: () => void; dark: boolean; onToggleDark: () => void;
}) {
  const filtered = conversations.filter(c => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return c.title.toLowerCase().includes(q) || c.preview.toLowerCase().includes(q);
  });
  const navItem = (label: string, icon: React.ReactNode, v: AppView) => (
    <button onClick={() => onViewChange(v)} className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm transition ${view === v ? "bg-[#EEF2FF] dark:bg-[#1A2340] text-[#1C3FCA] dark:text-[#4F6EE0] font-semibold" : "text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] hover:text-[#111827] dark:hover:text-[#F5F6FB]"}`}>
      {icon}{!collapsed && <span>{label}</span>}
    </button>
  );
  return (
    <aside className={`flex flex-col h-screen bg-white dark:bg-[#0D1428] border-r border-[#E5E7EB] dark:border-[#1F2D4A] transition-all duration-200 shrink-0 ${collapsed ? "w-0 overflow-hidden" : "w-[260px]"}`}>
      <div className="flex items-center justify-between px-4 py-4 border-b border-[#E5E7EB] dark:border-[#1F2D4A]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 overflow-hidden shrink-0 rounded-[3px]"><img src={hdfcLogo} alt="HDFC" className="w-full h-full object-contain" /></div>
          <span className="font-bold text-[#111827] dark:text-[#F5F6FB] text-[15px] tracking-tight">Nova</span>
        </div>
        <button onClick={onToggle} className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><ChevronLeft size={16} /></button>
      </div>
      <div className="px-3 pt-3 pb-2">
        <button onClick={onNewChat} className="flex items-center gap-2 w-full px-3 py-2 rounded-lg bg-[#1C3FCA] hover:bg-[#1535B0] text-white text-sm font-semibold transition shadow-sm shadow-[#1C3FCA]/20">
          <Plus size={15} /><span>New Chat</span>
        </button>
      </div>
      <div className="px-3 pb-2">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#F5F6FB] dark:bg-[#1A2340] border border-[#E5E7EB] dark:border-[#1F2D4A]">
          <Search size={13} className="text-[#9CA3AF] shrink-0" />
          <input type="text" placeholder="Search chats…" value={searchQuery} onChange={e => onSearch(e.target.value)} className="flex-1 bg-transparent text-xs text-[#374151] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] outline-none" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-3 pb-2" style={{ scrollbarWidth: "none" }}>
        {filtered.length > 0 && <p className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider px-1 mb-2">Recent</p>}
        <div className="space-y-0.5">
          {filtered.map(c => (
            <div key={c.session_id} className={`group flex items-center gap-1 rounded-lg transition ${currentSessionId === c.session_id ? "bg-[#EEF2FF] dark:bg-[#1A2340]" : "hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340]"}`}>
              <button onClick={() => onSelectConversation(c.session_id)} className="flex-1 min-w-0 text-left px-3 py-2.5">
                <p className={`text-xs font-medium truncate ${currentSessionId === c.session_id ? "text-[#1C3FCA] dark:text-[#4F6EE0]" : "text-[#374151] dark:text-[#9CA3AF]"}`}>{c.title}</p>
                <p className="text-[10px] text-[#9CA3AF] mt-0.5">{relativeDate(c.date)}</p>
              </button>
              <button onClick={e => { e.stopPropagation(); onDeleteConversation(c.session_id); }} className="shrink-0 mr-2 p-1 rounded opacity-0 group-hover:opacity-100 text-[#9CA3AF] hover:text-[#E22853] hover:bg-[#E22853]/10 transition"><Trash2 size={12} /></button>
            </div>
          ))}
          {filtered.length === 0 && searchQuery && <p className="text-xs text-[#9CA3AF] px-1 py-2">No chats match "{searchQuery}"</p>}
          {conversations.length === 0 && !searchQuery && <p className="text-xs text-[#9CA3AF] px-1 py-2">No previous conversations</p>}
        </div>
      </div>
      <div className="px-3 py-2 border-t border-[#E5E7EB] dark:border-[#1F2D4A] space-y-0.5">
        {navItem("Chat", <Bot size={15} />, "chat")}
        {navItem("Saved Documents", <Folder size={15} />, "documents")}
        {navItem("Saved Videos", <Film size={15} />, "videos")}
      </div>
      <div className="px-3 py-3 border-t border-[#E5E7EB] dark:border-[#1F2D4A]">
        <div className="flex items-center gap-2 px-2 py-1.5 mb-1">
          <div className="w-7 h-7 rounded-full bg-[#1C3FCA]/10 flex items-center justify-center shrink-0"><UserIcon size={12} className="text-[#1C3FCA]" /></div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-[#111827] dark:text-[#F5F6FB] truncate">{profile.full_name}</p>
            <p className="text-[10px] text-[#9CA3AF] capitalize">{profile.role}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onToggleDark} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition">
            {dark ? <Sun size={13} /> : <Moon size={13} />}<span>{dark ? "Light" : "Dark"}</span>
          </button>
          <button onClick={onSignOut} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs text-[#6B7280] hover:text-[#E22853] hover:bg-[#E22853]/6 dark:hover:bg-[#E22853]/10 transition">
            <LogOut size={13} /><span>Sign out</span>
          </button>
        </div>
      </div>
    </aside>
  );
}

// ─── My Documents Page ────────────────────────────────────────────────────────
function MyDocumentsPage({ profile, onNotify }: { profile: Profile; onNotify: (msg: string) => void }) {
  const [docs, setDocs] = useState<EmployeeDocument[]>(() =>
    MOCK_EMPLOYEE_DOCUMENTS.filter(d => d.user_id === profile.id)
  );
  const [reqDocs] = useState<RequiredDocument[]>(() => {
    const et = profile.employee_type;
    return MOCK_REQUIRED_DOCS.filter(d => {
      const t = d.employee_type as string;
      return t === "all" || t === "both" || t === et || t.split(",").map(s => s.trim()).includes(et);
    });
  });
  const [rejectingId, setRejectingId] = useState<string | null>(null);

  const mergedDocs = reqDocs.map(req => {
    const emp = docs.find(d => d.required_document_id === req.id);
    return { req, emp };
  });

  const approved = docs.filter(d => d.status === "approved").length;
  const pending = docs.filter(d => d.status === "pending_review" || d.status === "uploaded").length;
  const rejected = docs.filter(d => d.status === "rejected").length;
  const notUploaded = reqDocs.length - docs.filter(d => d.status !== "not_uploaded").length;

  const simulateUpload = (reqId: string, reqName: string) => {
    const existing = docs.find(d => d.required_document_id === reqId);
    if (existing) {
      setDocs(prev => prev.map(d => d.required_document_id === reqId ? { ...d, status: "pending_review", uploaded_at: new Date().toISOString(), remarks: undefined } : d));
    } else {
      setDocs(prev => [...prev, {
        id: uid(), user_id: profile.id, required_document_id: reqId, document_type: reqName,
        storage_path: `/mock/${reqName.toLowerCase().replace(/\s+/g, "_")}.pdf`,
        status: "pending_review", uploaded_at: new Date().toISOString(),
        file_name: `${reqName.toLowerCase().replace(/\s+/g, "_")}.pdf`, file_size: Math.random() * 2000000 + 300000,
      }]);
    }
    onNotify(`${reqName} submitted for review.`);
  };

  const statusIcon = (status: DocStatus) => {
    if (status === "approved") return <CheckCircle size={16} className="text-[#00875F]" />;
    if (status === "rejected") return <XCircle size={16} className="text-[#E22853]" />;
    if (status === "pending_review" || status === "uploaded") return <Clock size={16} className="text-[#F99F35]" />;
    return <Upload size={16} className="text-[#9CA3AF]" />;
  };

  const statsItems = [
    { label: "Approved", value: approved, color: "#00875F", bg: "#00875F" },
    { label: "Under Review", value: pending, color: "#F99F35", bg: "#F99F35" },
    { label: "Rejected", value: rejected, color: "#E22853", bg: "#E22853" },
    { label: "Not Uploaded", value: notUploaded < 0 ? 0 : notUploaded, color: "#9CA3AF", bg: "#9CA3AF" },
  ];

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">My Documents</h1>
        <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">Upload and track your onboarding documents</p>
      </div>
      <div className="px-8 py-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
        {statsItems.map(({ label, value, bg }) => (
          <div key={label} className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-4 shadow-sm">
            <p className="text-2xl font-bold" style={{ color: bg }}>{value}</p>
            <p className="text-xs text-[#9CA3AF] mt-0.5">{label}</p>
          </div>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto px-8 pb-8">
        <div className="space-y-3 max-w-2xl">
          {mergedDocs.map(({ req, emp }) => {
            const status: DocStatus = emp?.status ?? "not_uploaded";
            return (
              <div key={req.id} className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm hover:shadow-md transition">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${status === "approved" ? "bg-[#00875F]/10" : status === "rejected" ? "bg-[#E22853]/10" : status === "pending_review" ? "bg-[#F99F35]/10" : "bg-[#9CA3AF]/10"}`}>
                      {statusIcon(status)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{req.name}</h3>
                        <DocStatusBadge status={status} />
                        {req.mandatory && <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#E22853]/10 text-[#E22853]">Required</span>}
                      </div>
                      <p className="text-xs text-[#9CA3AF] mt-0.5">{req.description}</p>
                      {emp?.file_name && <p className="text-[11px] text-[#9CA3AF] mt-1">{emp.file_name}{emp.file_size ? ` · ${(emp.file_size / 1024 / 1024).toFixed(1)}MB` : ""} · {relativeDate(emp.uploaded_at)}</p>}
                      {emp?.remarks && status === "rejected" && (
                        <div className="mt-2 flex items-start gap-1.5 p-2.5 rounded-lg bg-[#E22853]/8 border border-[#E22853]/15">
                          <AlertCircle size={12} className="text-[#E22853] mt-0.5 shrink-0" />
                          <p className="text-[11px] text-[#E22853]">{emp.remarks}</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="shrink-0">
                    {(status === "not_uploaded" || status === "rejected") && (
                      <button onClick={() => simulateUpload(req.id, req.name)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1C3FCA] hover:bg-[#1535B0] text-white text-xs font-semibold transition shadow-sm">
                        <UploadCloud size={13} />{status === "rejected" ? "Re-upload" : "Upload"}
                      </button>
                    )}
                    {(status === "pending_review" || status === "approved") && (
                      <span className="text-xs text-[#9CA3AF]">{status === "approved" ? "Done" : "Submitted"}</span>
                    )}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2 pt-3 border-t border-[#F3F4F6] dark:border-[#1F2D4A]">
                  <p className="text-[10px] text-[#9CA3AF]">Accepted: {req.accepted_types.join(", ")} · Max {req.max_size_mb}MB</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {rejectingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setRejectingId(null)}>
          <div className="bg-white dark:bg-[#0D1428] rounded-2xl p-6 w-full max-w-sm shadow-xl" onClick={e => e.stopPropagation()}>
            <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-3">Demo modal — document actions simulated</p>
            <button onClick={() => setRejectingId(null)} className="w-full py-2 rounded-xl bg-[#1C3FCA] text-white text-sm font-semibold">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Resources/Videos Pages ───────────────────────────────────────────────────
function ResourcesPage({ profile, type }: { profile: Profile; type: "document" | "video" }) {
  const [search, setSearch] = useState("");
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [viewing, setViewing] = useState<DocumentMeta | VideoMeta | null>(null);

  const items = type === "document"
    ? MOCK_HR_DOCS.filter(d => {
        const et = d.employee_type ?? "all";
        return et === "all" || et === profile.employee_type;
      })
    : MOCK_HR_VIDEOS;

  const filtered = items.filter(item => {
    if (!search) return true;
    const q = search.toLowerCase();
    const title = (item as DocumentMeta).title || "";
    const desc = (item as DocumentMeta).description || "";
    return title.toLowerCase().includes(q) || desc.toLowerCase().includes(q);
  });

  const toggle = (id: string) => setSavedIds(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">{type === "document" ? "Documents" : "Videos"}</h1>
        <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{type === "document" ? "Onboarding guides and policy documents" : "Training videos and walkthroughs"}</p>
      </div>
      <div className="px-8 pt-5 pb-3">
        <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] max-w-sm">
          <Search size={14} className="text-[#9CA3AF] shrink-0" />
          <input type="text" placeholder={`Search ${type === "document" ? "documents" : "videos"}…`} value={search} onChange={e => setSearch(e.target.value)} className="flex-1 bg-transparent text-sm text-[#374151] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] outline-none" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-8 pb-8">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20"><FileText size={36} className="text-[#D1D5DB] mb-3" /><p className="text-[#9CA3AF] text-sm">No results for "{search}"</p></div>
        ) : (
          <div className="grid gap-3 max-w-2xl">
            {type === "document" ? (filtered as DocumentMeta[]).map(doc => (
              <div key={doc.id} className="flex items-center gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition">
                <div className="w-10 h-10 rounded-xl bg-[#1C3FCA]/10 flex items-center justify-center shrink-0"><FileText size={18} className="text-[#1C3FCA]" /></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{doc.title}</p>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EEF2FF] dark:bg-[#1A2340] text-[#1C3FCA] font-semibold">{doc.category}</span>
                  </div>
                  <p className="text-xs text-[#9CA3AF] mt-0.5 line-clamp-1">{doc.description}</p>
                  <div className="flex gap-1 mt-1.5 flex-wrap">{doc.tags.slice(0, 3).map(t => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-[#F5F6FB] dark:bg-[#1A2340] text-[#6B7280]">#{t}</span>)}</div>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <button onClick={() => toggle(doc.id)} className={`p-2 rounded-lg transition ${savedIds.has(doc.id) ? "text-[#1C3FCA] bg-[#EEF2FF]" : "text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF]"}`}><Bookmark size={14} fill={savedIds.has(doc.id) ? "currentColor" : "none"} /></button>
                  <button onClick={() => setViewing(doc)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition"><Eye size={14} /></button>
                </div>
              </div>
            )) : (filtered as VideoMeta[]).map(vid => (
              <div key={vid.id} className="flex items-center gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition">
                <div className="w-10 h-10 rounded-xl bg-[#E22853]/10 flex items-center justify-center shrink-0"><Film size={18} className="text-[#E22853]" /></div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{vid.title}</p>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">{vid.mentor} · {vid.duration} · {relativeDate(vid.uploaded_at)}</p>
                  <div className="flex gap-1 mt-1.5 flex-wrap">{vid.tags.slice(0, 3).map(t => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-[#F5F6FB] dark:bg-[#1A2340] text-[#6B7280]">#{t}</span>)}</div>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <button onClick={() => toggle(vid.id)} className={`p-2 rounded-lg transition ${savedIds.has(vid.id) ? "text-[#1C3FCA] bg-[#EEF2FF]" : "text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF]"}`}><Bookmark size={14} fill={savedIds.has(vid.id) ? "currentColor" : "none"} /></button>
                  <button onClick={() => setViewing(vid)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition"><Eye size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {viewing && "file_type" in viewing && <DocViewerModal doc={viewing as DocumentMeta} onClose={() => setViewing(null)} />}
      {viewing && "video_url" in viewing && <VideoViewerModal vid={viewing as VideoMeta} onClose={() => setViewing(null)} />}
    </div>
  );
}

// ─── Saved Items Page ─────────────────────────────────────────────────────────
function SavedItemsPage({ type, savedDocIds, savedVideoIds, onViewDoc, onViewVideo, onToggleDoc, onToggleVideo }: {
  type: AppView; savedDocIds: Set<string>; savedVideoIds: Set<string>;
  onViewDoc: (d: DocumentMeta) => void; onViewVideo: (v: VideoMeta) => void;
  onToggleDoc: (id: string) => void; onToggleVideo: (id: string) => void;
}) {
  const savedDocs = MOCK_HR_DOCS.filter(d => savedDocIds.has(d.id));
  const savedVids = MOCK_HR_VIDEOS.filter(v => savedVideoIds.has(v.id));
  const label = type === "documents" ? "Saved Documents" : "Saved Videos";
  const empty = type === "documents" ? savedDocs.length === 0 : savedVids.length === 0;

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">{label}</h1>
        <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{type === "documents" ? `${savedDocs.length} saved document${savedDocs.length !== 1 ? "s" : ""}` : `${savedVids.length} saved video${savedVids.length !== 1 ? "s" : ""}`}</p>
      </div>
      <div className="flex-1 overflow-y-auto px-8 py-6">
        {empty ? (
          <div className="flex flex-col items-center justify-center py-20">
            {type === "documents" ? <Folder size={36} className="text-[#D1D5DB] mb-3" /> : <Film size={36} className="text-[#D1D5DB] mb-3" />}
            <p className="text-[#9CA3AF] text-sm">No saved {type === "documents" ? "documents" : "videos"} yet</p>
            <p className="text-[#9CA3AF] text-xs mt-1">Bookmark items in Chat or while browsing resources</p>
          </div>
        ) : (
          <div className="space-y-2.5 max-w-2xl">
            {type === "documents" ? savedDocs.map(doc => <DocCard key={doc.id} doc={doc} onOpen={onViewDoc} isSaved={true} onSave={onToggleDoc} />) : savedVids.map(vid => <VidCard key={vid.id} vid={vid} onOpen={onViewVideo} isSaved={true} onSave={onToggleVideo} />)}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Chat Interface ───────────────────────────────────────────────────────────
function ChatInterface({ profile, conversations, setConversations, savedDocIds, savedVideoIds, onSaveDoc, onSaveVideo, dark, onToggleDark, onSignOut, onNavigateHome }: {
  profile: Profile; conversations: ConversationSummary[]; setConversations: React.Dispatch<React.SetStateAction<ConversationSummary[]>>;
  savedDocIds: Set<string>; savedVideoIds: Set<string>; onSaveDoc: (id: string) => void; onSaveVideo: (id: string) => void;
  dark: boolean; onToggleDark: () => void; onSignOut: () => void; onNavigateHome?: () => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([novaMsg("Hi! I'm Nova 👋 How can I help you today?", "greeting")]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [phase, setPhase] = useState<Phase>("intent");
  const [prevIntent, setPrevIntent] = useState<Intent | null>(null);
  const [hasUserMessage, setHasUserMessage] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [view, setView] = useState<AppView>("chat");
  const [collapsed, setCollapsed] = useState(false);
  const [viewingDoc, setViewingDoc] = useState<DocumentMeta | null>(null);
  const [viewingVid, setViewingVid] = useState<VideoMeta | null>(null);
  const [notifMsg, setNotifMsg] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { speak, stop: stopSpeech, enabled: voiceOut, setEnabled: setVoiceOut } = useVoiceOutput();
  const { listening, toggle: toggleMic, supported: micSupported } = useVoiceInput((t) => { setInput(t); setTimeout(() => sendMessage(t), 100); });

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);
  useEffect(() => { if (textareaRef.current) { textareaRef.current.style.height = "auto"; textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + "px"; } }, [input]);

  const showNotif = (msg: string) => { setNotifMsg(msg); setTimeout(() => setNotifMsg(null), 3000); };

  const startNewChat = () => {
    setMessages([novaMsg("Hi! I'm Nova 👋 How can I help you today?", "greeting")]);
    setPhase("intent"); setPrevIntent(null); setHasUserMessage(false); setInput(""); setView("chat");
    setCurrentSessionId(null);
  };

  const restoreConversation = (sid: string) => {
    const conv = conversations.find(c => c.session_id === sid);
    if (!conv) return;
    const restoredMsgs: ChatMessage[] = [
      novaMsg("Hi! I'm Nova 👋 How can I help you today?", "greeting"),
      { id: uid(), speaker: "user", text: conv.title, phase: "intent", timestamp: new Date(conv.date) },
      novaMsg(conv.preview.split("—").slice(1).join("—").trim() || "I can help with that! Feel free to ask more.", "post_response", "team_info"),
    ];
    setMessages(restoredMsgs); setHasUserMessage(true); setPhase("post_response"); setCurrentSessionId(sid); setView("chat");
  };

  const deleteConversation = (sid: string) => {
    setConversations(prev => prev.filter(c => c.session_id !== sid));
    if (currentSessionId === sid) startNewChat();
  };

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || thinking || phase === "end") return;
    stopSpeech();
    setHasUserMessage(true);
    const userMsg: ChatMessage = { id: uid(), speaker: "user", text: text.trim(), phase, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput(""); setThinking(true);
    const typingId = uid();
    setMessages(prev => [...prev, { id: typingId, speaker: "nova", text: "", phase, timestamp: new Date(), isTyping: true }]);
    await new Promise(r => setTimeout(r, 500 + Math.random() * 400));
    setMessages(prev => prev.filter(m => m.id !== typingId));

    const trimmed = text.trim();

    // Save to conversations on first message
    if (!currentSessionId && !conversations.find(c => c.title === trimmed)) {
      const sid = uid();
      setCurrentSessionId(sid);
      setConversations(prev => [{ session_id: sid, title: trimmed.slice(0, 40), preview: trimmed, date: new Date().toISOString() }, ...prev]);
    }

    if (phase === "post_response" && isEndSignal(trimmed)) {
      const farewell = "Glad I could help! Feel free to reach out anytime. Have a great day! 😊";
      setMessages(prev => [...prev, novaMsg(farewell, "end")]);
      speak(farewell); setPhase("end"); setThinking(false); return;
    }

    if (isGreeting(trimmed)) {
      const reply = `Hey! Great to hear from you. I can help you with:\n\n• 👥 Team info — your team, mentor, teammates\n• 🏢 Office details — location, timings, seating\n• 🔐 Access & credentials — ID card, email, accounts\n• 💻 Hardware & IT — system, laptop, IT support\n• 📋 HR policies — leave, holidays, attendance\n• 💰 Benefits — salary slip, reimbursement, perks\n\nWhat would you like to know?`;
      setMessages(prev => [...prev, novaMsg(reply, "intent")]);
      speak(reply); setPhase("post_response"); setThinking(false); return;
    }

    if (isElicitation(trimmed) && classifyIntent(trimmed) === "unknown") {
      const reply = `Welcome to HDFC! I'm here to make your onboarding smooth. Here's what I can help you with:\n\n• 👥 Team info — your team, mentor, teammates\n• 🏢 Office details — location, timings, seating\n• 🔐 Access & credentials — ID card, email, accounts\n• 💻 Hardware & IT — system, laptop, IT support\n• 📋 HR policies — leave, holidays, attendance\n• 💰 Benefits — salary slip, reimbursement, perks\n\nWhat would you like to know first?`;
      setMessages(prev => [...prev, novaMsg(reply, "intent")]);
      speak(reply); setPhase("post_response"); setThinking(false); return;
    }

    const intent = classifyIntent(trimmed);

    if (intent === "unknown") {
      // Try to find in knowledge base across all intents
      let kbBest: string | null = null; let kbBestScore = 0;
      for (const intentKey of Object.keys(KNOWLEDGE_BASE) as Intent[]) {
        const result = scoreEntries(KNOWLEDGE_BASE[intentKey] ?? [], trimmed, profile.employee_type);
        if (result && result.score > kbBestScore) { kbBestScore = result.score; kbBest = result.entry.answer; }
      }
      if (kbBestScore > 0 && kbBest) {
        setMessages(prev => [...prev, novaMsg(kbBest!, "answer")]); speak(kbBest);
        setPhase("post_response"); setThinking(false); return;
      }

      if (phase === "clarification") {
        const isHdfc = looksHdfcRelated(trimmed);
        if (isHdfc) {
          const escIntent = prevIntent ?? "unknown";
          const routedTo = ESCALATION_MAP[escIntent];
          setMessages(prev => [...prev, novaMsg("I'm unable to find that information right now. Please contact the relevant team for assistance.", "escalation", escIntent, { routed_to: routedTo })]);
        } else {
          const capMsg = "So sorry, I can't help you with that! I'm designed specifically for HDFC Bank onboarding queries. Here's what I can help you with:\n\n• 👥 Team info\n• 🏢 Office details\n• 🔐 Access & credentials\n• 💻 Hardware & IT\n• 📋 HR policies\n• 💰 Benefits\n\nFeel free to ask me anything in these areas!";
          setMessages(prev => [...prev, novaMsg(capMsg, "intent")]); speak(capMsg);
        }
        setPhase("post_response");
      } else {
        const clarMsg = "Please rephrase your question, I didn't quite get that.";
        setMessages(prev => [...prev, novaMsg(clarMsg, "clarification")]); speak(clarMsg);
        setPhase("clarification");
      }
      setThinking(false); return;
    }

    setPrevIntent(intent);
    const answer = retrieveAnswer(intent, trimmed, profile.employee_type, profile);

    if (!answer) {
      const routedTo = ESCALATION_MAP[intent];
      setMessages(prev => [...prev, novaMsg(`I wasn't able to find specific information about that. Please reach out to the relevant team.`, "escalation", intent, { routed_to: routedTo })]);
      setPhase("post_response"); setThinking(false); return;
    }

    setMessages(prev => [...prev, novaMsg(answer, "post_response", intent)]);
    speak(answer); setPhase("post_response"); setThinking(false);
    textareaRef.current?.focus();
  }, [thinking, phase, prevIntent, currentSessionId, conversations, profile, speak, stopSpeech]);

  const handleKey = (e: React.KeyboardEvent) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); } };

  const QUICK_REPLIES = profile.employee_type === "intern"
    ? ["Which team am I in?", "Who is my mentor?", "Where do I sit in the office?", "Will I get a laptop?", "What is the leave policy?", "Do I get an HDFC email?"]
    : ["Which team am I in?", "Who is my mentor?", "Where do I sit in the office?", "When will I get my system?", "What is the leave policy?", "Can my travel cost be reimbursed?"];

  const renderContent = () => {
    if (view === "chat") {
      return (
        <div className="flex-1 flex flex-col min-h-0">
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5" style={{ scrollbarWidth: "none" }}>
            {!hasUserMessage ? (
              <WelcomeScreen profile={profile} onSend={sendMessage} />
            ) : (
              messages.map(msg => (
                msg.speaker === "nova"
                  ? <NovaBubble key={msg.id} msg={msg} onViewDoc={setViewingDoc} onViewVideo={setViewingVid} savedDocIds={savedDocIds} savedVideoIds={savedVideoIds} onSaveDoc={onSaveDoc} onSaveVideo={onSaveVideo} contacts={[]} />
                  : <UserBubble key={msg.id} msg={msg} />
              ))
            )}
            <div ref={bottomRef} />
          </div>
          {hasUserMessage && phase !== "end" && (
            <div className="px-4 pb-3 flex gap-2 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
              {QUICK_REPLIES.map(qr => (
                <button key={qr} onClick={() => sendMessage(qr)} className="shrink-0 px-3 py-1.5 rounded-full text-xs border border-[#D2D5DB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428] text-[#374151] dark:text-[#9CA3AF] hover:border-[#1C3FCA] hover:text-[#1C3FCA] hover:bg-[#F3F6FD] dark:hover:bg-[#1A2340] transition whitespace-nowrap">{qr}</button>
              ))}
            </div>
          )}
          <div className="px-4 pb-4 pt-2 border-t border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
            <div className="flex items-end gap-2 max-w-3xl mx-auto">
              {micSupported && (
                <button onClick={toggleMic} className={`shrink-0 p-3 rounded-xl border transition ${listening ? "bg-[#E22853]/10 border-[#E22853]/30 text-[#E22853]" : "border-[#E5E7EB] dark:border-[#1F2D4A] text-[#9CA3AF] hover:text-[#1C3FCA] hover:border-[#1C3FCA]"}`}>
                  {listening ? <MicOff size={16} /> : <Mic size={16} />}
                </button>
              )}
              <div className="flex-1 flex items-end gap-2 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] bg-[#F5F6FB] dark:bg-[#1A2340] px-4 py-2.5 focus-within:ring-2 focus-within:ring-[#1C3FCA] focus-within:border-transparent transition">
                <textarea ref={textareaRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey} placeholder="Ask Nova anything…" rows={1} className="flex-1 bg-transparent text-sm text-[#111827] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] outline-none resize-none leading-relaxed" style={{ maxHeight: "120px" }} />
              </div>
              <button onClick={() => { speak(""); setVoiceOut(v => !v); }} title={voiceOut ? "Mute voice" : "Enable voice"} className={`shrink-0 p-3 rounded-xl border transition ${voiceOut ? "bg-[#1C3FCA]/10 border-[#1C3FCA]/30 text-[#1C3FCA]" : "border-[#E5E7EB] dark:border-[#1F2D4A] text-[#9CA3AF] hover:text-[#1C3FCA] hover:border-[#1C3FCA]"}`}>
                {voiceOut ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>
              <button onClick={() => sendMessage(input)} disabled={!input.trim() || thinking || phase === "end"} className="shrink-0 p-3 rounded-xl bg-[#1C3FCA] hover:bg-[#1535B0] text-white transition disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-[#1C3FCA]/20">
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      );
    }
    if (view === "documents") return <SavedItemsPage type="documents" savedDocIds={savedDocIds} savedVideoIds={savedVideoIds} onViewDoc={setViewingDoc} onViewVideo={setViewingVid} onToggleDoc={onSaveDoc} onToggleVideo={onSaveVideo} />;
    if (view === "videos") return <SavedItemsPage type="videos" savedDocIds={savedDocIds} savedVideoIds={savedVideoIds} onViewDoc={setViewingDoc} onViewVideo={setViewingVid} onToggleDoc={onSaveDoc} onToggleVideo={onSaveVideo} />;
    return null;
  };

  return (
    <div className="h-screen flex bg-white dark:bg-[#0D1428] overflow-hidden" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      <Sidebar
        collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} view={view} onViewChange={setView}
        conversations={conversations} searchQuery={searchQuery} onSearch={setSearchQuery}
        onNewChat={startNewChat} onSelectConversation={restoreConversation} onDeleteConversation={deleteConversation}
        currentSessionId={currentSessionId} profile={profile} onSignOut={onSignOut} dark={dark} onToggleDark={onToggleDark}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <header className="flex items-center gap-3 px-4 py-3 bg-white dark:bg-[#0D1428] border-b border-[#E5E7EB] dark:border-[#1F2D4A] shrink-0">
          {collapsed && (
            <button onClick={() => setCollapsed(false)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><Menu size={16} /></button>
          )}
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 overflow-hidden shrink-0 rounded-sm"><img src={hdfcLogo} alt="HDFC" className="w-full h-full object-contain" /></div>
            <span className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">Nova · HDFC Bank</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {onNavigateHome && (
              <button onClick={onNavigateHome} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-[#6B7280] dark:text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340] transition">
                <Home size={13} /><span className="hidden sm:inline">Dashboard</span>
              </button>
            )}
            <button onClick={onToggleDark} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition">{dark ? <Sun size={15} /> : <Moon size={15} />}</button>
          </div>
        </header>
        <div className="flex-1 flex flex-col min-h-0 bg-white dark:bg-[#0D1428]">
          {renderContent()}
        </div>
      </div>
      {viewingDoc && <DocViewerModal doc={viewingDoc} onClose={() => setViewingDoc(null)} />}
      {viewingVid && <VideoViewerModal vid={viewingVid} onClose={() => setViewingVid(null)} />}
      {notifMsg && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 bg-[#111827] dark:bg-white text-white dark:text-[#111827] rounded-xl shadow-xl text-sm font-medium">
          <CheckCircle size={15} />{notifMsg}
        </div>
      )}
    </div>
  );
}

// ─── Employee App ─────────────────────────────────────────────────────────────
// ─── Employee Dashboard ───────────────────────────────────────────────────────
function EmployeeDashboard({ profile, onTabChange }: { profile: Profile; onTabChange: (tab: string) => void }) {
  const myDocs = MOCK_EMPLOYEE_DOCUMENTS.filter(d => d.user_id === profile.id);
  const approved = myDocs.filter(d => d.status === "approved").length;
  const pending = myDocs.filter(d => d.status === "pending_review" || d.status === "uploaded").length;
  const rejected = myDocs.filter(d => d.status === "rejected").length;
  const notUploaded = myDocs.filter(d => d.status === "not_uploaded").length;
  const total = myDocs.length;
  const pct = total > 0 ? Math.round((approved / total) * 100) : 0;

  const isIntern = profile.role === "intern";

  const greet = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  };

  const checklist = [
    { done: true,                            label: "Account created & demo login active" },
    { done: approved > 0,                    label: "Identity documents uploaded" },
    { done: approved > 0 && pending === 0 && rejected === 0, label: "All documents approved by HR" },
    { done: false,                           label: isIntern ? "Complete internship orientation session" : "Complete joining formalities with HR" },
    { done: false,                           label: "Set up HDFC email and system access" },
  ];

  const announcements = [
    {
      title: "Welcome to HDFC Bank!",
      body: "We're thrilled to have you on board. Please complete your document submission at your earliest convenience.",
      time: "Just now", color: "#1C3FCA",
    },
    {
      title: isIntern ? "Intern Orientation — 30 June" : "New Joiner Connect — 5 July",
      body: isIntern
        ? "Your orientation session is scheduled. Join via the Microsoft Teams link shared by your mentor."
        : "All new joiners are invited to the New Joiner Connect session. Details sent to your HDFC email.",
      time: "2 days ago", color: "#F99F35",
    },
    {
      title: "IT Access Request",
      body: "Submit your IT asset request form via the IT helpdesk portal. Your laptop will be issued within 3 working days.",
      time: "3 days ago", color: "#00875F",
    },
  ];

  const mentorName: string = isIntern ? (profile.mentor_name ?? "Kunal Jasuja") : "Rajesh Kumar";
  const mentorRole = isIntern ? "Mentor · Payment Factory" : "Manager · Technology";
  const mentorInitials = mentorName.split(" ").map((n: string) => n[0]).join("").slice(0, 2);

  return (
    <div className="flex-1 overflow-y-auto bg-[#F9FAFF] dark:bg-[#0A0F1E]" style={{ scrollbarWidth: "thin" }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1C3FCA] to-[#3050D8] px-8 py-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)", backgroundSize: "22px 22px" }} />
        <div className="relative max-w-5xl mx-auto">
          <div className="flex items-center gap-2 mb-1">
            {isIntern ? <GraduationCap size={13} className="text-[#90CAF9]" /> : <Briefcase size={13} className="text-[#90CAF9]" />}
            <span className="text-[#90CAF9] text-xs font-medium uppercase tracking-wider">{isIntern ? "Intern" : "Permanent Employee"} · {profile.team ?? profile.department ?? "HDFC Bank"}</span>
          </div>
          <h1 className="text-2xl font-bold text-white mt-1">{greet()}, {profile.full_name.split(" ")[0]}!</h1>
          <p className="text-[#BFDBFE] text-sm mt-0.5">Here's your onboarding overview.</p>
          <div className="mt-5 flex items-center gap-5">
            <div className="flex-1 max-w-xs">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs text-[#90CAF9]">Onboarding Progress</span>
                <span className="text-xs font-bold text-white">{pct}%</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white rounded-full" style={{ width: `${pct}%` }} />
              </div>
            </div>
            <div className="shrink-0 text-center">
              <p className="text-white font-bold text-xl leading-none">{approved}<span className="text-[#90CAF9] text-sm font-normal">/{total}</span></p>
              <p className="text-[#90CAF9] text-[10px] mt-0.5">docs approved</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-8 py-6 max-w-5xl mx-auto">
        {/* Doc stat tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {[
            { label: "Approved",     value: approved,    icon: <CheckCircle size={17} />, color: "#00875F", bg: "#ECFDF5", darkBg: "#0A2218" },
            { label: "Pending Review", value: pending,   icon: <Clock size={17} />,       color: "#F99F35", bg: "#FFF7E6", darkBg: "#241800" },
            { label: "Rejected",     value: rejected,    icon: <XCircle size={17} />,     color: "#E22853", bg: "#FFF0F3", darkBg: "#200410" },
            { label: "Not Uploaded", value: notUploaded, icon: <UploadCloud size={17} />, color: "#6B7280", bg: "#F3F4F6", darkBg: "#1A1E2A" },
          ].map(s => (
            <button key={s.label} onClick={() => onTabChange("documents")}
              className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-4 shadow-sm hover:shadow-md hover:border-[#1C3FCA]/30 transition text-left">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center mb-2" style={{ background: s.bg, color: s.color }}>{s.icon}</div>
              <p className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">{s.value}</p>
              <p className="text-xs text-[#9CA3AF] mt-0.5">{s.label}</p>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Left: Checklist + Announcements */}
          <div className="lg:col-span-2 space-y-5">
            {/* Checklist */}
            <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <ClipboardList size={14} className="text-[#1C3FCA]" />
                <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">Onboarding Checklist</h2>
                <span className="ml-auto text-xs text-[#9CA3AF]">{checklist.filter(c => c.done).length}/{checklist.length} done</span>
              </div>
              <div className="space-y-3">
                {checklist.map((item, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition ${item.done ? "bg-[#00875F] border-[#00875F]" : "border-[#D1D5DB] dark:border-[#374151]"}`}>
                      {item.done && <Check size={11} className="text-white" />}
                    </div>
                    <p className={`text-sm leading-snug ${item.done ? "line-through text-[#9CA3AF]" : "text-[#374151] dark:text-[#9CA3AF]"}`}>{item.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Announcements */}
            <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Bell size={14} className="text-[#1C3FCA]" />
                <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">Announcements</h2>
              </div>
              <div className="space-y-3">
                {announcements.map((a, i) => (
                  <div key={i} className="flex gap-3 p-3.5 rounded-xl bg-[#F9FAFF] dark:bg-[#0A1428] border border-[#E5E7EB] dark:border-[#1F2D4A]">
                    <div className="w-1 rounded-full shrink-0" style={{ background: a.color, minHeight: "44px" }} />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">{a.title}</p>
                      <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mt-0.5 leading-relaxed">{a.body}</p>
                      <p className="text-[10px] text-[#9CA3AF] mt-1">{a.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: People + Quick actions + Details */}
          <div className="space-y-5">
            {/* Mentor / Manager */}
            <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <UserCheck size={14} className="text-[#1C3FCA]" />
                <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{isIntern ? "Your Mentor" : "Your Manager"}</h2>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1C3FCA] to-[#4F6EE0] flex items-center justify-center text-white font-bold text-sm shrink-0">{mentorInitials}</div>
                <div>
                  <p className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">{mentorName}</p>
                  <p className="text-xs text-[#9CA3AF]">{mentorRole}</p>
                </div>
              </div>
              <button onClick={() => onTabChange("chat")} className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-xs font-medium text-[#1C3FCA] hover:bg-[#EEF2FF] dark:hover:bg-[#1A2340] transition">
                <Bot size={12} /> Ask Nova about {isIntern ? "your mentor" : "your manager"}
              </button>
            </div>

            {/* Quick actions */}
            <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
              <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm mb-3">Quick Actions</h2>
              <div className="space-y-2">
                {[
                  { label: "Chat with Nova",        icon: <Bot size={13} />,        tab: "chat",      color: "#1C3FCA", bg: "#EEF2FF" },
                  { label: "Upload Documents",       icon: <UploadCloud size={13} />,tab: "documents", color: "#00875F", bg: "#ECFDF5" },
                  { label: "View Resources",         icon: <Folder size={13} />,     tab: "resources", color: "#F99F35", bg: "#FFF7E6" },
                  { label: "Watch Training Videos",  icon: <Film size={13} />,       tab: "videos",    color: "#E22853", bg: "#FFF0F3" },
                ].map(a => (
                  <button key={a.label} onClick={() => onTabChange(a.tab)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-sm text-[#374151] dark:text-[#9CA3AF] hover:bg-[#F9FAFF] dark:hover:bg-[#1A2340] transition text-left">
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0" style={{ background: a.bg, color: a.color }}>{a.icon}</div>
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Employee details */}
            <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
              <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm mb-3">Your Details</h2>
              <div className="space-y-2">
                {[
                  { label: "Employee ID",   value: profile.id },
                  { label: "Team",          value: profile.team ?? "—" },
                  { label: "Branch",        value: profile.branch ?? "—" },
                  { label: "Joining Date",  value: profile.joining_date ? new Date(profile.joining_date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—" },
                ].map(row => (
                  <div key={row.label} className="flex justify-between gap-2 text-xs">
                    <span className="text-[#9CA3AF]">{row.label}</span>
                    <span className="font-medium text-[#374151] dark:text-[#9CA3AF] text-right truncate max-w-[160px]">{row.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmployeeApp({ profile, onSignOut }: { profile: Profile; onSignOut: () => void }) {
  const [dark, setDark] = useDarkMode();
  const [activeTab, setActiveTab] = useState<"home" | "chat" | "documents" | "resources" | "videos">("home");
  const [conversations, setConversations] = useState<ConversationSummary[]>(MOCK_CONVERSATIONS);
  const [savedDocIds, setSavedDocIds] = useState<Set<string>>(new Set(["doc-1", "doc-3"]));
  const [savedVideoIds, setSavedVideoIds] = useState<Set<string>>(new Set(["vid-1"]));

  const toggleDoc = (id: string) => setSavedDocIds(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleVideo = (id: string) => setSavedVideoIds(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const tabs: { key: typeof activeTab; label: string; icon: React.ReactNode }[] = [
    { key: "home",      label: "Home",       icon: <Home size={15} /> },
    { key: "chat",      label: "Chat",       icon: <Bot size={15} /> },
    { key: "documents", label: "My Docs",    icon: <FileCheck size={15} /> },
    { key: "resources", label: "Resources",  icon: <Folder size={15} /> },
    { key: "videos",    label: "Videos",     icon: <Film size={15} /> },
  ];

  if (activeTab === "chat") {
    return (
      <ChatInterface
        profile={profile} conversations={conversations} setConversations={setConversations}
        savedDocIds={savedDocIds} savedVideoIds={savedVideoIds} onSaveDoc={toggleDoc} onSaveVideo={toggleVideo}
        dark={dark} onToggleDark={() => setDark(d => !d)} onSignOut={onSignOut}
        onNavigateHome={() => setActiveTab("home")}
      />
    );
  }

  return (
    <div className="h-screen flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      <header className="flex items-center gap-3 px-6 py-3.5 bg-white dark:bg-[#0D1428] border-b border-[#E5E7EB] dark:border-[#1F2D4A] shrink-0">
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-6 h-6 overflow-hidden shrink-0 rounded-sm"><img src={hdfcLogo} alt="HDFC" className="w-full h-full object-contain" /></div>
          <span className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">Nova · HDFC Bank</span>
        </div>
        <nav className="flex items-center gap-0.5 ml-4">
          {tabs.map(({ key, label, icon }) => (
            <button key={key} onClick={() => setActiveTab(key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition ${activeTab === key ? "bg-[#EEF2FF] dark:bg-[#1A2340] text-[#1C3FCA] font-semibold" : "text-[#6B7280] dark:text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB]"}`}>
              {icon}<span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <button onClick={() => setDark(d => !d)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition">{dark ? <Sun size={15} /> : <Moon size={15} />}</button>
          <button onClick={onSignOut} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-[#6B7280] hover:text-[#E22853] hover:bg-[#E22853]/8 transition"><LogOut size={13} /><span className="hidden sm:inline">Sign out</span></button>
        </div>
      </header>
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        {activeTab === "home"      && <EmployeeDashboard profile={profile} onTabChange={(t) => setActiveTab(t as typeof activeTab)} />}
        {activeTab === "documents" && <MyDocumentsPage profile={profile} onNotify={() => {}} />}
        {activeTab === "resources" && <ResourcesPage profile={profile} type="document" />}
        {activeTab === "videos"    && <ResourcesPage profile={profile} type="video" />}
      </div>
    </div>
  );
}

// ─── HR Dashboard ─────────────────────────────────────────────────────────────
function HRDashboard({ onNavigate }: { onNavigate: (v: HRView, filter?: "pending" | "approved" | "rejected") => void }) {
  const stats = [
    { label: "Total Employees", value: 8, icon: <Users size={18} />, color: "#1C3FCA", bg: "#EEF2FF", trend: "+2 this month" },
    { label: "Docs Pending Review", value: 4, icon: <Clock size={18} />, color: "#F99F35", bg: "#FFF7E6", trend: "Action needed", action: () => onNavigate("reviews", "pending") },
    { label: "Docs Approved", value: 11, icon: <CheckCircle size={18} />, color: "#00875F", bg: "#E6F7F2", trend: "All time", action: () => onNavigate("reviews", "approved") },
    { label: "Docs Rejected", value: 2, icon: <XCircle size={18} />, color: "#E22853", bg: "#FFF0F3", trend: "Needs re-upload", action: () => onNavigate("reviews", "rejected") },
  ];

  const recentActivity = [
    { name: "Arjun Mehta",   action: "submitted",  doc: "PAN Card",           time: "2 hours ago",  type: "intern" },
    { name: "Sneha Pillai",  action: "re-uploaded", doc: "Bank Details",       time: "5 hours ago",  type: "intern" },
    { name: "Priya Nair",    action: "submitted",   doc: "Bank Account Details",time: "Yesterday",  type: "permanent" },
    { name: "Aditya Verma",  action: "submitted",   doc: "Aadhaar Card",       time: "2 days ago",   type: "intern" },
    { name: "Meera Joshi",   action: "submitted",   doc: "Passport Photo",     time: "3 days ago",   type: "permanent" },
  ];

  const empTypeCounts = [
    { label: "Interns", count: 3, color: "#F99F35" },
    { label: "Permanent", count: 4, color: "#1C3FCA" },
    { label: "Contract", count: 1, color: "#9333EA" },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#F9FAFF] dark:bg-[#0A0F1E]">
      <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">HR Dashboard</h1>
        <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">Overview of onboarding activity · {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
      </div>
      <div className="px-8 py-6 max-w-5xl">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(({ label, value, icon, color, bg, trend, action }) => (
            <div key={label} onClick={action} className={`bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition ${action ? "cursor-pointer" : ""}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: bg, color }}>{icon}</div>
                {action && <ChevronRight size={14} className="text-[#9CA3AF]" />}
              </div>
              <p className="text-2xl font-bold text-[#111827] dark:text-[#F5F6FB]">{value}</p>
              <p className="text-xs font-medium text-[#374151] dark:text-[#9CA3AF] mt-0.5">{label}</p>
              <p className="text-[10px] text-[#9CA3AF] mt-1">{trend}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Activity chart */}
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-4">Weekly Activity</h3>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={DASH_ACTIVITY} barSize={10} barGap={3}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#111827", border: "none", borderRadius: "8px", color: "#F5F6FB", fontSize: "12px" }} />
                <Bar dataKey="docs" name="Documents" fill="#1C3FCA" radius={[4, 4, 0, 0]} />
                <Bar dataKey="chats" name="Chats" fill="#D0DDFC" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Onboarding trend */}
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-4">New Joiners Trend</h3>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={ONBOARD_TREND}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#111827", border: "none", borderRadius: "8px", color: "#F5F6FB", fontSize: "12px" }} />
                <Line type="monotone" dataKey="count" stroke="#1C3FCA" strokeWidth={2.5} dot={{ r: 4, fill: "#1C3FCA" }} name="New Joiners" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB]">Recent Activity</h3>
              <button onClick={() => onNavigate("reviews")} className="text-xs text-[#1C3FCA] hover:underline">View all</button>
            </div>
            <div className="space-y-3">
              {recentActivity.map(({ name, action, doc, time, type }) => (
                <div key={`${name}-${doc}`} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#1C3FCA]/10 flex items-center justify-center shrink-0 text-[#1C3FCA] text-xs font-bold">{name[0]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-[#111827] dark:text-[#F5F6FB]"><span className="font-semibold">{name}</span> {action} <span className="text-[#1C3FCA]">{doc}</span></p>
                    <p className="text-[10px] text-[#9CA3AF]">{time}</p>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold capitalize ${type === "intern" ? "bg-[#F99F35]/15 text-[#B86F00]" : type === "contract" ? "bg-[#9333EA]/15 text-[#9333EA]" : "bg-[#1C3FCA]/10 text-[#1C3FCA]"}`}>{type}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Employee breakdown */}
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-4">Employee Breakdown</h3>
            <div className="space-y-4">
              {empTypeCounts.map(({ label, count, color }) => (
                <div key={label}>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-xs font-medium text-[#374151] dark:text-[#9CA3AF]">{label}</span>
                    <span className="text-xs font-bold text-[#111827] dark:text-[#F5F6FB]">{count}</span>
                  </div>
                  <div className="h-2 bg-[#F5F6FB] dark:bg-[#1A2340] rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${(count / 8) * 100}%`, background: color }} />
                  </div>
                </div>
              ))}
              <button onClick={() => onNavigate("employees")} className="w-full mt-3 py-2 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-xs font-medium text-[#374151] dark:text-[#9CA3AF] hover:border-[#1C3FCA] hover:text-[#1C3FCA] transition">View Directory</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Employee Directory ───────────────────────────────────────────────────────
function EmployeeDirectory({ onSelectEmployee }: { onSelectEmployee: (id: string) => void }) {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "intern" | "permanent" | "contract">("all");

  const filtered = MOCK_EMPLOYEES.filter(e => {
    if (typeFilter !== "all" && e.role !== typeFilter) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return e.full_name.toLowerCase().includes(q) || e.email.toLowerCase().includes(q) || e.team.toLowerCase().includes(q) || e.department.toLowerCase().includes(q);
  });

  const typeColor = (role: UserRole) => {
    if (role === "intern") return "bg-[#F99F35]/15 text-[#B86F00]";
    if (role === "contract") return "bg-[#9333EA]/15 text-[#9333EA]";
    return "bg-[#1C3FCA]/10 text-[#1C3FCA]";
  };

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-5 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <div className="max-w-3xl mx-auto flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">Employee Directory</h1>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{filtered.length} of {MOCK_EMPLOYEES.length} employees</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#F5F6FB] dark:bg-[#1A2340] border border-[#E5E7EB] dark:border-[#1F2D4A] min-w-[200px]">
            <Search size={14} className="text-[#9CA3AF] shrink-0" />
            <input type="text" placeholder="Search employees…" value={search} onChange={e => setSearch(e.target.value)} className="flex-1 bg-transparent text-sm text-[#374151] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] outline-none" />
          </div>
        </div>
        <div className="max-w-3xl mx-auto flex gap-2 mt-4 flex-wrap">
          {(["all", "intern", "permanent", "contract"] as const).map(key => (
            <button key={key} onClick={() => setTypeFilter(key)} className={`px-4 py-1.5 rounded-full text-xs font-semibold transition capitalize ${typeFilter === key ? "bg-[#1C3FCA] text-white" : "bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] text-[#6B7280] dark:text-[#9CA3AF] hover:border-[#1C3FCA] hover:text-[#1C3FCA]"}`}>{key === "all" ? "All" : key.charAt(0).toUpperCase() + key.slice(1)}</button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-4">
        <div className="max-w-3xl mx-auto px-6 space-y-2.5">
          {filtered.map(emp => (
            <div key={emp.id} className="flex items-center gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition cursor-pointer group" onClick={() => onSelectEmployee(emp.id)}>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1C3FCA] to-[#4F6EE0] flex items-center justify-center text-white font-bold text-sm shrink-0">{emp.full_name.split(" ").map(n => n[0]).join("").slice(0, 2)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{emp.full_name}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold capitalize ${typeColor(emp.role)}`}>{emp.role}</span>
                </div>
                <p className="text-xs text-[#9CA3AF] mt-0.5">{emp.team} · {emp.branch} · Joined {relativeDate(emp.joining_date)}</p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full" style={{ background: emp.doc_summary.approved === emp.doc_summary.total ? "#00875F" : emp.doc_summary.pending > 0 ? "#F99F35" : "#E22853" }} />
                  <span className="text-xs text-[#9CA3AF]">{emp.doc_summary.approved}/{emp.doc_summary.total} docs</span>
                </div>
                <ChevronRight size={15} className="text-[#D1D5DB] group-hover:text-[#1C3FCA] transition" />
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20"><Users size={36} className="text-[#D1D5DB] mb-3" /><p className="text-[#9CA3AF] text-sm">No employees found</p></div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Employee Profile View (HR) ───────────────────────────────────────────────
function EmployeeProfileView({ employeeId, onBack }: { employeeId: string; onBack: () => void }) {
  const emp = MOCK_EMPLOYEES.find(e => e.id === employeeId);
  const [docs, setDocs] = useState<EmployeeDocument[]>(() => MOCK_EMPLOYEE_DOCUMENTS.filter(d => d.user_id === employeeId));
  const [rejectReason, setRejectReason] = useState<{ id: string; reason: string } | null>(null);
  const [notif, setNotif] = useState<string | null>(null);
  const [previewingDoc, setPreviewingDoc] = useState<EmployeeDocument | null>(null);

  const showNotif = (msg: string) => { setNotif(msg); setTimeout(() => setNotif(null), 2500); };

  const approve = (id: string) => {
    setDocs(prev => prev.map(d => d.id === id ? { ...d, status: "approved", reviewed_at: new Date().toISOString(), remarks: undefined } : d));
    showNotif("Document approved.");
  };

  const reject = (id: string, reason: string) => {
    setDocs(prev => prev.map(d => d.id === id ? { ...d, status: "rejected", reviewed_at: new Date().toISOString(), remarks: reason } : d));
    setRejectReason(null); showNotif("Document rejected with reason.");
  };

  if (!emp) return <div className="flex-1 flex items-center justify-center text-[#9CA3AF]">Employee not found.</div>;

  const typeColor = (role: UserRole) => {
    if (role === "intern") return "bg-[#F99F35]/15 text-[#B86F00]";
    if (role === "contract") return "bg-[#9333EA]/15 text-[#9333EA]";
    return "bg-[#1C3FCA]/10 text-[#1C3FCA]";
  };

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-5 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-[#6B7280] hover:text-[#1C3FCA] mb-4 transition"><ArrowLeft size={14} /> Back to Directory</button>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#1C3FCA] to-[#4F6EE0] flex items-center justify-center text-white font-bold text-lg shrink-0">{emp.full_name.split(" ").map(n => n[0]).join("").slice(0, 2)}</div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">{emp.full_name}</h1>
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold capitalize ${typeColor(emp.role)}`}>{emp.role}</span>
            </div>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{emp.email}</p>
            <div className="flex gap-4 mt-1.5 text-xs text-[#9CA3AF] flex-wrap">
              <span>{emp.team}</span><span>·</span><span>{emp.department}</span><span>·</span><span>{emp.branch}</span><span>·</span><span>Joined {relativeDate(emp.joining_date)}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-8 py-6">
        <div className="max-w-2xl">
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[{ label: "Approved", value: emp.doc_summary.approved, color: "#00875F" }, { label: "Pending", value: emp.doc_summary.pending, color: "#F99F35" }, { label: "Rejected", value: emp.doc_summary.rejected, color: "#E22853" }].map(({ label, value, color }) => (
              <div key={label} className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-4 shadow-sm text-center">
                <p className="text-2xl font-bold" style={{ color }}>{value}</p>
                <p className="text-xs text-[#9CA3AF] mt-0.5">{label}</p>
              </div>
            ))}
          </div>
          <h2 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-3">Documents</h2>
          {docs.length === 0 ? (
            <p className="text-sm text-[#9CA3AF]">No documents submitted yet.</p>
          ) : (
            <div className="space-y-3">
              {docs.map(doc => (
                <div key={doc.id} className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${doc.status === "approved" ? "bg-[#00875F]/10" : doc.status === "rejected" ? "bg-[#E22853]/10" : "bg-[#F99F35]/10"}`}>
                        {doc.status === "approved" ? <CheckCircle size={16} className="text-[#00875F]" /> : doc.status === "rejected" ? <XCircle size={16} className="text-[#E22853]" /> : <Clock size={16} className="text-[#F99F35]" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{doc.document_type}</p>
                          <DocStatusBadge status={doc.status} />
                        </div>
                        {doc.file_name && <p className="text-[11px] text-[#9CA3AF] mt-0.5">{doc.file_name}{doc.file_size ? ` · ${(doc.file_size / 1024 / 1024).toFixed(1)}MB` : ""} · Uploaded {relativeDate(doc.uploaded_at)}</p>}
                        {doc.remarks && <div className="mt-2 p-2 rounded-lg bg-[#E22853]/8 border border-[#E22853]/15"><p className="text-[11px] text-[#E22853]">HR note: "{doc.remarks}"</p></div>}
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      {doc.status !== "not_uploaded" && (
                        <button onClick={() => setPreviewingDoc(doc)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition" title="Preview document"><Eye size={14} /></button>
                      )}
                      {(doc.status === "pending_review" || doc.status === "uploaded") && (
                        <>
                          <button onClick={() => approve(doc.id)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#00875F]/10 text-[#00875F] hover:bg-[#00875F] hover:text-white transition"><Check size={12} />Approve</button>
                          <button onClick={() => setRejectReason({ id: doc.id, reason: "" })} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#E22853]/10 text-[#E22853] hover:bg-[#E22853] hover:text-white transition"><X size={12} />Reject</button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {previewingDoc && emp && (
        <EmployeeDocPreviewModal doc={previewingDoc} employeeName={emp.full_name} onClose={() => setPreviewingDoc(null)} />
      )}
      {/* Rejection reason modal */}
      {rejectReason && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setRejectReason(null)}>
          <div className="bg-white dark:bg-[#0D1428] rounded-2xl p-6 w-full max-w-sm shadow-xl border border-[#E5E7EB] dark:border-[#1F2D4A]" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-[#111827] dark:text-[#F5F6FB] mb-1">Reject Document</h3>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mb-4">Enter a reason so the employee knows what to fix.</p>
            <textarea value={rejectReason.reason} onChange={e => setRejectReason(r => r ? { ...r, reason: e.target.value } : null)} placeholder="e.g. Document is blurry, please re-upload a clearer scan." rows={3} className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] bg-[#F9FAFF] dark:bg-[#1A2340] text-sm text-[#111827] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1C3FCA] mb-4 resize-none" />
            <div className="flex gap-2">
              <button onClick={() => setRejectReason(null)} className="flex-1 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-sm text-[#6B7280] hover:bg-[#F5F6FB] transition">Cancel</button>
              <button onClick={() => rejectReason.reason.trim() && reject(rejectReason.id, rejectReason.reason.trim())} disabled={!rejectReason.reason.trim()} className="flex-1 py-2.5 rounded-xl bg-[#E22853] hover:bg-[#C0122F] text-white text-sm font-semibold transition disabled:opacity-50">Reject</button>
            </div>
          </div>
        </div>
      )}
      {notif && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 bg-[#111827] text-white rounded-xl shadow-xl text-sm font-medium">
          <CheckCircle size={15} />{notif}
        </div>
      )}
    </div>
  );
}

// ─── Document Reviews Page (HR) ───────────────────────────────────────────────
function DocumentReviewsPage({ onSelectEmployee, defaultFilter }: { onSelectEmployee: (id: string) => void; defaultFilter?: "pending" | "approved" | "rejected" }) {
  type DocRow = EmployeeDocument & { employee_name: string; employee_type_label: string };
  const [statusFilter, setStatusFilter] = useState<"pending" | "approved" | "rejected" | "all">(defaultFilter ?? "all");
  const [previewingDoc, setPreviewingDoc] = useState<DocRow | null>(null);
  const [allDocs] = useState<DocRow[]>(() =>
    MOCK_EMPLOYEE_DOCUMENTS.filter(d => d.status !== "not_uploaded").map(d => {
      const emp = MOCK_EMPLOYEES.find(e => e.id === d.user_id);
      const rawType = emp?.role ?? "permanent";
      const emp_type = rawType === "intern" ? "Intern" : rawType === "permanent" ? "Permanent" : rawType === "contract" ? "Contract" : rawType;
      return { ...d, employee_name: emp?.full_name ?? "Employee", employee_type_label: emp_type };
    })
  );

  const visibleDocs = allDocs.filter(d => {
    if (statusFilter === "pending") return d.status === "pending_review" || d.status === "uploaded";
    if (statusFilter === "approved") return d.status === "approved";
    if (statusFilter === "rejected") return d.status === "rejected";
    return true;
  });

  const countFor = (key: string) => allDocs.filter(d => {
    if (key === "pending") return d.status === "pending_review" || d.status === "uploaded";
    if (key === "approved") return d.status === "approved";
    if (key === "rejected") return d.status === "rejected";
    return true;
  }).length;

  const filterTabs: { key: typeof statusFilter; label: string }[] = [
    { key: "all", label: "All" }, { key: "pending", label: "Needs Review" }, { key: "approved", label: "Approved" }, { key: "rejected", label: "Rejected" },
  ];

  const iconForStatus = (s: string) => {
    if (s === "approved") return <CheckCircle size={16} className="text-[#00875F]" />;
    if (s === "rejected") return <XCircle size={16} className="text-[#E22853]" />;
    return <FileText size={16} className="text-[#F99F35]" />;
  };
  const bgForStatus = (s: string) => {
    if (s === "approved") return "bg-[#00875F]/10";
    if (s === "rejected") return "bg-[#E22853]/10";
    return "bg-[#F99F35]/10";
  };

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-5 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">Document Reviews</h1>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{visibleDocs.length} document{visibleDocs.length !== 1 ? "s" : ""} · {allDocs.length} total</p>
        </div>
      </div>
      <div className="pt-4 pb-2 bg-[#F9FAFF] dark:bg-[#0A0F1E]">
        <div className="max-w-3xl mx-auto px-6 flex gap-2 flex-wrap">
          {filterTabs.map(t => (
            <button key={t.key} onClick={() => setStatusFilter(t.key)} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition ${statusFilter === t.key ? "bg-[#1C3FCA] text-white shadow-sm" : "bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] text-[#6B7280] dark:text-[#9CA3AF] hover:border-[#1C3FCA] hover:text-[#1C3FCA]"}`}>
              {t.label}
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${statusFilter === t.key ? "bg-white/25 text-white" : "bg-[#F5F6FB] dark:bg-[#1A2340] text-[#374151] dark:text-[#9CA3AF]"}`}>{countFor(t.key)}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-3">
        <div className="max-w-3xl mx-auto px-6">
          {visibleDocs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20"><FileText size={36} className="text-[#D1D5DB] mb-3" /><p className="text-[#9CA3AF] text-sm font-medium">No documents match this filter</p></div>
          ) : (
            <div className="space-y-2.5">
              {visibleDocs.map(d => (
                <div key={d.id} className="flex items-center gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:border-[#1C3FCA]/30 transition">
                  <div className={`w-9 h-9 rounded-xl ${bgForStatus(d.status)} flex items-center justify-center shrink-0`}>{iconForStatus(d.status)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">{d.document_type}</p>
                      <DocStatusBadge status={d.status as DocStatus} />
                    </div>
                    <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">
                      <span className="font-medium text-[#374151] dark:text-[#9CA3AF]">{d.employee_name}</span> · {d.employee_type_label} · Uploaded {relativeDate(d.uploaded_at)}
                      {d.file_name && <span className="ml-1 text-[#9CA3AF]">· {d.file_name}{d.file_size ? ` (${(d.file_size / 1024 / 1024).toFixed(1)}MB)` : ""}</span>}
                    </p>
                    {d.remarks && <p className="text-[10px] text-[#E22853] mt-0.5 italic">HR note: "{d.remarks}"</p>}
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    <button onClick={() => setPreviewingDoc(d)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition" title="Preview document"><Eye size={14} /></button>
                    <button onClick={() => onSelectEmployee(d.user_id)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#1C3FCA]/10 text-[#1C3FCA] hover:bg-[#1C3FCA] hover:text-white transition">
                      Profile <ChevronRight size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {previewingDoc && (
        <EmployeeDocPreviewModal doc={previewingDoc} employeeName={previewingDoc.employee_name} onClose={() => setPreviewingDoc(null)} />
      )}
    </div>
  );
}

// ─── HR Content Browser (Docs/Videos) ────────────────────────────────────────
function HRContentBrowser({ type }: { type: "document" | "video" }) {
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<DocumentMeta | VideoMeta | null>(null);
  const [viewing, setViewing] = useState<DocumentMeta | VideoMeta | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const items = type === "document" ? MOCK_HR_DOCS : MOCK_HR_VIDEOS;
  const filtered = items.filter(item => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (item as DocumentMeta).title.toLowerCase().includes(q) || (item as DocumentMeta).description.toLowerCase().includes(q);
  });

  const label = type === "document" ? "Documents" : "Videos";
  const Icon = type === "document" ? FileText : Film;
  const iconColor = type === "document" ? "text-[#1C3FCA]" : "text-[#E22853]";
  const iconBg = type === "document" ? "bg-[#1C3FCA]/10" : "bg-[#E22853]/10";

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-5 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <div className="max-w-3xl mx-auto flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">{label} Repository</h1>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">Manage {label.toLowerCase()} visible to employees</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1C3FCA] hover:bg-[#1535B0] text-white text-sm font-semibold transition shadow-sm shrink-0">
            <Plus size={15} /> Add {type === "document" ? "Document" : "Video"}
          </button>
        </div>
        <div className="max-w-3xl mx-auto mt-4 flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#F5F6FB] dark:bg-[#1A2340] border border-[#E5E7EB] dark:border-[#1F2D4A]">
          <Search size={14} className="text-[#9CA3AF] shrink-0" />
          <input type="text" placeholder={`Search ${label.toLowerCase()}…`} value={search} onChange={e => setSearch(e.target.value)} className="flex-1 bg-transparent text-sm text-[#374151] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] outline-none" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-4">
        <div className="max-w-3xl mx-auto px-6 space-y-2.5">
          {filtered.map(item => (
            <div key={item.id} className="flex items-center gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition">
              <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center shrink-0`}><Icon size={18} className={iconColor} /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-[#111827] dark:text-[#F5F6FB] text-sm">{(item as DocumentMeta).title}</p>
                  {type === "document" && (item as DocumentMeta).category && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EEF2FF] dark:bg-[#1A2340] text-[#1C3FCA] font-semibold">{(item as DocumentMeta).category}</span>
                  )}
                  {type === "video" && (item as VideoMeta).duration && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E22853]/10 text-[#E22853] font-semibold">{(item as VideoMeta).duration}</span>
                  )}
                </div>
                <p className="text-xs text-[#9CA3AF] mt-0.5 line-clamp-1">{(item as DocumentMeta).description}</p>
                <p className="text-[10px] text-[#9CA3AF] mt-1">
                  {type === "document" ? `Uploaded by ${(item as DocumentMeta).uploaded_by}` : `Mentor: ${(item as VideoMeta).mentor}`} · {relativeDate((item as DocumentMeta).uploaded_at)}
                </p>
              </div>
              <div className="flex gap-1.5 shrink-0">
                <button onClick={() => setViewing(item)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition" title="Preview"><Eye size={14} /></button>
                <button onClick={() => setEditing(item)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition" title="Edit"><Pencil size={14} /></button>
                <button className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#E22853] hover:bg-[#E22853]/8 transition" title="Delete"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Add Modal (demo) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setShowAddModal(false)}>
          <div className="bg-white dark:bg-[#0D1428] rounded-2xl p-6 w-full max-w-sm shadow-xl border border-[#E5E7EB] dark:border-[#1F2D4A]" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-[#111827] dark:text-[#F5F6FB] mb-1">Add {type === "document" ? "Document" : "Video"}</h3>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mb-5">Upload forms are disabled in portfolio demo mode. In production, employees would see the {type} in their resources.</p>
            <button onClick={() => setShowAddModal(false)} className="w-full py-2.5 rounded-xl bg-[#1C3FCA] text-white text-sm font-semibold">Got it</button>
          </div>
        </div>
      )}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setEditing(null)}>
          <div className="bg-white dark:bg-[#0D1428] rounded-2xl p-6 w-full max-w-sm shadow-xl border border-[#E5E7EB] dark:border-[#1F2D4A]" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-[#111827] dark:text-[#F5F6FB] mb-1">Edit {type === "document" ? "Document" : "Video"}</h3>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mb-5">Edit functionality is disabled in portfolio demo mode. In production, changes would be saved and reflected instantly for employees.</p>
            <button onClick={() => setEditing(null)} className="w-full py-2.5 rounded-xl bg-[#1C3FCA] text-white text-sm font-semibold">Close</button>
          </div>
        </div>
      )}
      {viewing && "file_type" in viewing && <DocViewerModal doc={viewing as DocumentMeta} onClose={() => setViewing(null)} />}
      {viewing && "video_url" in viewing && <VideoViewerModal vid={viewing as VideoMeta} onClose={() => setViewing(null)} />}
    </div>
  );
}

// ─── Required Document Manager (HR) ──────────────────────────────────────────
function RequiredDocumentManager() {
  const [docs, setDocs] = useState<RequiredDocument[]>(MOCK_REQUIRED_DOCS);
  const [typeFilter, setTypeFilter] = useState<"all" | "intern" | "permanent" | "contract">("all");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<RequiredDocument | null>(null);
  const [form, setForm] = useState({ name: "", description: "", mandatory: true, accepted_types: "PDF, JPG, PNG", max_size_mb: 10, selectedTypes: ["intern", "permanent", "contract"] as string[] });

  const openNew = () => { setEditing(null); setForm({ name: "", description: "", mandatory: true, accepted_types: "PDF, JPG, PNG", max_size_mb: 10, selectedTypes: ["intern", "permanent", "contract"] }); setShowForm(true); };
  const openEdit = (d: RequiredDocument) => {
    const et = d.employee_type as string;
    const types = (!et || et === "all" || et === "both") ? ["intern", "permanent", "contract"] : et.split(",").map(t => t.trim());
    setEditing(d); setForm({ name: d.name, description: d.description, mandatory: d.mandatory, accepted_types: Array.isArray(d.accepted_types) ? d.accepted_types.join(", ") : d.accepted_types, max_size_mb: d.max_size_mb, selectedTypes: types }); setShowForm(true);
  };
  const save = () => {
    const storedType = form.selectedTypes.length === 3 ? "all" : form.selectedTypes.join(",") as "intern" | "permanent" | "contract" | "all" | "both";
    const payload: RequiredDocument = { id: editing?.id ?? uid(), name: form.name, description: form.description, mandatory: form.mandatory, accepted_types: form.accepted_types.split(",").map(t => t.trim()), max_size_mb: form.max_size_mb, employee_type: storedType, created_at: editing?.created_at ?? new Date().toISOString() };
    if (editing) { setDocs(prev => prev.map(d => d.id === editing.id ? payload : d)); }
    else { setDocs(prev => [...prev, payload]); }
    setShowForm(false);
  };
  const del = (id: string) => { if (confirm("Delete this required document?")) setDocs(prev => prev.filter(d => d.id !== id)); };

  const visibleDocs = typeFilter === "all" ? docs : docs.filter(d => {
    const et = (d.employee_type ?? "all") as string;
    const ts = (et === "all" || et === "both") ? ["intern", "permanent", "contract"] : et.split(",").map(t => t.trim());
    return ts.includes(typeFilter);
  });

  const iCls = "w-full px-3.5 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] bg-[#F9FAFF] dark:bg-[#1A2340] text-sm text-[#111827] dark:text-[#F5F6FB] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1C3FCA]";
  const lbl = "block text-xs font-semibold text-[#374151] dark:text-[#9CA3AF] mb-1.5 uppercase tracking-wide";

  const toggleType = (t: string) => setForm(f => ({ ...f, selectedTypes: f.selectedTypes.includes(t) ? f.selectedTypes.filter(x => x !== t) : [...f.selectedTypes, t] }));

  return (
    <div className="flex-1 flex flex-col bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden">
      <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
        <div className="max-w-3xl mx-auto flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">Required Documents</h1>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">Manage document requirements for employees</p>
          </div>
          <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1C3FCA] hover:bg-[#1535B0] text-white text-sm font-semibold transition shadow-sm shrink-0"><Plus size={15} />Add Document</button>
        </div>
      </div>
      <div className="pt-4 pb-2 border-b border-[#E5E7EB] dark:border-[#1F2D4A]">
        <div className="max-w-3xl mx-auto px-6 flex gap-2 flex-wrap">
          {(["all", "intern", "permanent", "contract"] as const).map(key => {
            const count = key === "all" ? docs.length : docs.filter(d => { const et = (d.employee_type ?? "all") as string; const ts = (et === "all" || et === "both") ? ["intern", "permanent", "contract"] : et.split(",").map(t => t.trim()); return ts.includes(key); }).length;
            const active = key === "all" ? "bg-[#1C3FCA] text-white" : key === "intern" ? "bg-[#F99F35] text-white" : key === "permanent" ? "bg-[#00875F] text-white" : "bg-[#9333EA] text-white";
            return (
              <button key={key} onClick={() => setTypeFilter(key)} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition capitalize ${typeFilter === key ? active : "bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] text-[#6B7280] dark:text-[#9CA3AF] hover:text-[#374151]"}`}>
                {key === "all" ? "All" : key.charAt(0).toUpperCase() + key.slice(1)}
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${typeFilter === key ? "bg-white/25 text-white" : "bg-[#F5F6FB] dark:bg-[#1A2340] text-[#374151] dark:text-[#9CA3AF]"}`}>{count}</span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-6">
        <div className="max-w-3xl mx-auto px-6 space-y-3">
          {visibleDocs.map(d => {
            const et = d.employee_type as string;
            const types = (!et || et === "all" || et === "both") ? ["intern", "permanent", "contract"] : et.split(",").map(t => t.trim());
            const typeCfg: Record<string, string> = { intern: "bg-[#F99F35]/15 text-[#B86F00]", permanent: "bg-[#00875F]/15 text-[#00875F]", contract: "bg-[#9333EA]/15 text-[#9333EA]" };
            return (
              <div key={d.id} className="flex items-start gap-4 p-4 bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB]">{d.name}</h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${d.mandatory ? "bg-[#E22853]/10 text-[#E22853]" : "bg-[#9CA3AF]/10 text-[#9CA3AF]"}`}>{d.mandatory ? "Required" : "Optional"}</span>
                    {types.length === 3 ? <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-[#1C3FCA]/10 text-[#1C3FCA]">All Employees</span> : types.map(t => <span key={t} className={`text-[10px] px-2 py-0.5 rounded-full font-semibold capitalize ${typeCfg[t] ?? "bg-[#9CA3AF]/10 text-[#9CA3AF]"}`}>{t}</span>)}
                  </div>
                  <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">{d.description}</p>
                  <p className="text-[11px] text-[#9CA3AF] mt-1">{Array.isArray(d.accepted_types) ? d.accepted_types.join(", ") : d.accepted_types} · Max {d.max_size_mb}MB</p>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => openEdit(d)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#1C3FCA] hover:bg-[#EEF2FF] transition"><Pencil size={14} /></button>
                  <button onClick={() => del(d.id)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#E22853] hover:bg-[#E22853]/8 transition"><Trash2 size={14} /></button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div className="bg-white dark:bg-[#0D1428] rounded-2xl p-6 w-full max-w-md shadow-xl border border-[#E5E7EB] dark:border-[#1F2D4A] max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-[#111827] dark:text-[#F5F6FB] mb-5">{editing ? "Edit" : "Add"} Required Document</h3>
            <div className="space-y-4">
              <div><label className={lbl}>Document Name</label><input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Aadhaar Card" className={iCls} /></div>
              <div><label className={lbl}>Description</label><textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Brief description of what this document is" rows={2} className={iCls + " resize-none"} /></div>
              <div>
                <label className={lbl}>Applies to</label>
                <div className="flex gap-2 flex-wrap">
                  {["intern", "permanent", "contract"].map(t => (
                    <button key={t} type="button" onClick={() => toggleType(t)} className={`px-3 py-1.5 rounded-full text-xs font-semibold capitalize transition ${form.selectedTypes.includes(t) ? "bg-[#1C3FCA] text-white" : "border border-[#E5E7EB] dark:border-[#1F2D4A] text-[#6B7280] hover:border-[#1C3FCA] hover:text-[#1C3FCA]"}`}>{t}</button>
                  ))}
                </div>
              </div>
              <div><label className={lbl}>Accepted Formats (comma-separated)</label><input type="text" value={form.accepted_types} onChange={e => setForm(f => ({ ...f, accepted_types: e.target.value }))} className={iCls} /></div>
              <div className="flex gap-4">
                <div className="flex-1"><label className={lbl}>Max Size (MB)</label><input type="number" value={form.max_size_mb} onChange={e => setForm(f => ({ ...f, max_size_mb: parseInt(e.target.value) || 10 }))} className={iCls} /></div>
                <div className="flex-1 flex items-end pb-0.5"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={form.mandatory} onChange={e => setForm(f => ({ ...f, mandatory: e.target.checked }))} className="rounded" /><span className="text-sm font-medium text-[#374151] dark:text-[#9CA3AF]">Mandatory</span></label></div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-sm text-[#6B7280] hover:bg-[#F5F6FB] transition">Cancel</button>
              <button onClick={save} disabled={!form.name.trim() || form.selectedTypes.length === 0} className="flex-1 py-2.5 rounded-xl bg-[#1C3FCA] hover:bg-[#1535B0] text-white text-sm font-semibold transition disabled:opacity-50">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── HR Sidebar ───────────────────────────────────────────────────────────────
function HRSidebar({ view, onViewChange, profile, onSignOut, dark, onToggleDark, collapsed, onToggle }: {
  view: HRView; onViewChange: (v: HRView) => void; profile: Profile; onSignOut: () => void;
  dark: boolean; onToggleDark: () => void; collapsed: boolean; onToggle: () => void;
}) {
  const items: { view: HRView; label: string; icon: React.ReactNode }[] = [
    { view: "dashboard",     label: "Dashboard",          icon: <BarChart2 size={16} /> },
    { view: "employees",     label: "Employees",          icon: <Users size={16} /> },
    { view: "reviews",       label: "Document Reviews",   icon: <FileCheck size={16} /> },
    { view: "knowledge",     label: "Documents",          icon: <FileText size={16} /> },
    { view: "videos",        label: "Videos",             icon: <Film size={16} /> },
    { view: "required_docs", label: "Required Documents", icon: <ClipboardList size={16} /> },
    { view: "settings",      label: "Settings",           icon: <Settings size={16} /> },
  ];
  return (
    <aside className={`flex flex-col h-screen bg-white dark:bg-[#0D1428] border-r border-[#E5E7EB] dark:border-[#1F2D4A] transition-all duration-200 shrink-0 ${collapsed ? "w-0 overflow-hidden" : "w-[220px]"}`}>
      <div className="flex items-center justify-between px-4 py-4 border-b border-[#E5E7EB] dark:border-[#1F2D4A]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 overflow-hidden shrink-0 rounded-[3px]"><img src={hdfcLogo} alt="HDFC" className="w-full h-full object-contain" /></div>
          <span className="font-bold text-[#111827] dark:text-[#F5F6FB] text-[13px] tracking-tight">Nova HR</span>
        </div>
        <button onClick={onToggle} className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><ChevronLeft size={16} /></button>
      </div>
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {items.map(item => (
          <button key={item.view} onClick={() => onViewChange(item.view)}
            className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm transition ${view === item.view ? "bg-[#EEF2FF] dark:bg-[#1A2340] text-[#1C3FCA] dark:text-[#4F6EE0] font-semibold" : "text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] hover:text-[#111827] dark:hover:text-[#F5F6FB]"}`}>
            {item.icon}<span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="px-3 py-3 border-t border-[#E5E7EB] dark:border-[#1F2D4A] space-y-1">
        <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg">
          <div className="w-7 h-7 rounded-full bg-[#1C3FCA]/10 flex items-center justify-center shrink-0"><Shield size={12} className="text-[#1C3FCA]" /></div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-[#111827] dark:text-[#F5F6FB] truncate">{profile.full_name}</p>
            <p className="text-[10px] text-[#9CA3AF]">{profile.role === "hr" ? "HR" : "Admin"}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onToggleDark} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition">{dark ? <Sun size={13} /> : <Moon size={13} />}<span>{dark ? "Light" : "Dark"}</span></button>
          <button onClick={onSignOut} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs text-[#6B7280] hover:text-[#E22853] hover:bg-[#E22853]/6 dark:hover:bg-[#E22853]/10 transition"><LogOut size={13} /><span>Sign out</span></button>
        </div>
      </div>
    </aside>
  );
}

// ─── HR Portal ────────────────────────────────────────────────────────────────
function HRPortal({ profile, onSignOut }: { profile: Profile; onSignOut: () => void }) {
  const [dark, setDark] = useDarkMode();
  const [collapsed, setCollapsed] = useState(false);
  const [view, setView] = useState<HRView>("dashboard");
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [reviewsFilter, setReviewsFilter] = useState<"pending" | "approved" | "rejected" | undefined>(undefined);

  const handleSelectEmployee = (id: string) => { setSelectedEmployeeId(id); setView("employees"); };

  const handleNavigate = (v: HRView, filter?: "pending" | "approved" | "rejected") => {
    setSelectedEmployeeId(null); setReviewsFilter(filter); setView(v);
  };

  const renderMain = () => {
    if (view === "employees" && selectedEmployeeId) return <EmployeeProfileView employeeId={selectedEmployeeId} onBack={() => setSelectedEmployeeId(null)} />;
    if (view === "employees") return <EmployeeDirectory onSelectEmployee={handleSelectEmployee} />;
    if (view === "reviews") return <DocumentReviewsPage onSelectEmployee={handleSelectEmployee} defaultFilter={reviewsFilter} />;
    if (view === "knowledge") return <HRContentBrowser type="document" />;
    if (view === "videos") return <HRContentBrowser type="video" />;
    if (view === "required_docs") return <RequiredDocumentManager />;
    if (view === "settings") return (
      <div className="flex-1 bg-[#F9FAFF] dark:bg-[#0A0F1E]">
        <div className="px-8 py-6 border-b border-[#E5E7EB] dark:border-[#1F2D4A] bg-white dark:bg-[#0D1428]">
          <h1 className="text-xl font-bold text-[#111827] dark:text-[#F5F6FB]">Settings</h1>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">HR portal configuration</p>
        </div>
        <div className="px-8 py-6 max-w-xl space-y-4">
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition group">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-1 group-hover:text-[#1C3FCA] transition">HR Profile</h3>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{profile.full_name} · {profile.email}</p>
            <p className="text-xs text-[#9CA3AF] mt-1">Role: {profile.role === "hr" ? "HR" : "Admin"}</p>
          </div>
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-[#1C3FCA]/20 transition group">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-2 group-hover:text-[#1C3FCA] transition">Theme</h3>
            <button onClick={() => setDark(d => !d)} className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#E5E7EB] dark:border-[#1F2D4A] text-sm text-[#374151] dark:text-[#9CA3AF] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition">
              {dark ? <Sun size={14} /> : <Moon size={14} />}{dark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            </button>
          </div>
          <div className="bg-white dark:bg-[#0D1428] border border-[#E5E7EB] dark:border-[#1F2D4A] rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-[#E22853]/20 transition group">
            <h3 className="font-semibold text-[#111827] dark:text-[#F5F6FB] mb-1 group-hover:text-[#E22853] transition">Sign Out</h3>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mb-3">End your current HR session and return to the login screen.</p>
            <button onClick={onSignOut} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#E22853]/10 border border-[#E22853]/20 text-sm font-medium text-[#E22853] hover:bg-[#E22853] hover:text-white transition">
              <LogOut size={14} /> Sign Out
            </button>
          </div>
        </div>
      </div>
    );
    return <HRDashboard onNavigate={handleNavigate} />;
  };

  return (
    <div className="h-screen flex bg-[#F9FAFF] dark:bg-[#0A0F1E] overflow-hidden" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      <HRSidebar view={view} onViewChange={(v) => { setView(v); setSelectedEmployeeId(null); setReviewsFilter(undefined); }}
        profile={profile} onSignOut={onSignOut} dark={dark} onToggleDark={() => setDark(d => !d)}
        collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <div className="flex-1 flex flex-col min-w-0">
        <header className="flex items-center gap-3 px-4 py-3 bg-white dark:bg-[#0D1428] border-b border-[#E5E7EB] dark:border-[#1F2D4A] shrink-0">
          <button onClick={() => setCollapsed(c => !c)} className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#374151] dark:hover:text-[#F5F6FB] hover:bg-[#F5F6FB] dark:hover:bg-[#1A2340] transition"><Menu size={16} /></button>
          <span className="text-sm font-semibold text-[#111827] dark:text-[#F5F6FB]">HDFC Bank · HR Portal</span>
          <div className="ml-auto flex items-center gap-2 px-3 py-1.5 bg-[#1C3FCA]/10 border border-[#1C3FCA]/20 rounded-full">
            <Shield size={11} className="text-[#1C3FCA]" />
            <span className="text-xs font-semibold text-[#1C3FCA]">{profile.role === "hr" ? "HR" : "Admin"}</span>
          </div>
        </header>
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">{renderMain()}</div>
      </div>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [profile, setProfile] = useState<Profile | null>(null);

  if (!profile) return <AuthGate onAuth={setProfile} />;

  const role = (profile.role ?? "").toLowerCase().trim();
  if (role === "hr" || role === "admin") return <HRPortal profile={profile} onSignOut={() => setProfile(null)} />;
  return <EmployeeApp profile={profile} onSignOut={() => setProfile(null)} />;
}
